import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Phone, Mail, MapPin, Clock, Send, CheckCircle } from 'lucide-react';

interface ContactProps {
  theme: 'dark' | 'light';
  language: 'en' | 'ur';
}

const Contact: React.FC<ContactProps> = ({ theme, language }) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    service: '',
    message: ''
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  const content = {
    en: {
      title: "Get In Touch",
      subtitle: "Ready to start your solar journey? We're here to help!",
      form: {
        name: "Full Name",
        email: "Email Address",
        phone: "Phone Number",
        service: "Select Service",
        message: "Your Message",
        submit: "Send Message",
        success: "Thank you! We'll get back to you soon."
      },
      services: [
        "Residential Solar",
        "Commercial Solar",
        "Industrial Solutions",
        "Maintenance & Support",
        "Consultation"
      ],
      contact: {
        phone: "+1 (555) 123-4567",
        email: "info@solartech.com",
        address: "123 Solar Street, Green City, GC 12345",
        hours: "Mon - Fri: 8:00 AM - 6:00 PM"
      }
    },
    ur: {
      title: "رابطہ کریں",
      subtitle: "اپنا سولر سفر شروع کرنے کے لیے تیار ہیں؟ ہم آپ کی مدد کے لیے حاضر ہیں!",
      form: {
        name: "مکمل نام",
        email: "ای میل ایڈریس",
        phone: "فون نمبر",
        service: "خدمت منتخب کریں",
        message: "آپ کا پیغام",
        submit: "پیغام بھیجیں",
        success: "شکریہ! ہم جلد ہی آپ سے رابطہ کریں گے۔"
      },
      services: [
        "رہائشی سولر",
        "تجارتی سولر",
        "صنعتی حل",
        "دیکھ بھال اور سپورٹ",
        "مشاورت"
      ],
      contact: {
        phone: "+1 (555) 123-4567",
        email: "info@solartech.com",
        address: "123 سولر سٹریٹ، گرین سٹی، GC 12345",
        hours: "پیر - جمعہ: صبح 8:00 - شام 6:00"
      }
    }
  };

  const currentContent = content[language];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 3000);
  };

  return (
    <section id="contact" className={`py-20 ${theme === 'dark' ? 'bg-gray-900/50' : 'bg-gray-50'}`} ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className={`text-center mb-16 ${language === 'ur' ? 'rtl' : ''}`}
        >
          <h2 className={`text-4xl sm:text-5xl font-bold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
            <span className="bg-gradient-to-r from-green-400 to-yellow-400 bg-clip-text text-transparent">
              {currentContent.title}
            </span>
          </h2>
          <p className={`text-xl ${
            theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
          } max-w-3xl mx-auto ${language === 'ur' ? 'font-urdu' : ''}`}>
            {currentContent.subtitle}
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-8"
          >
            <div className={`p-8 rounded-3xl ${
              theme === 'dark' 
                ? 'bg-white/5 border border-white/10' 
                : 'bg-white border border-gray-200'
            } backdrop-blur-md shadow-xl`}>
              <h3 className={`text-2xl font-bold mb-6 ${language === 'ur' ? 'font-urdu' : ''}`}>
                {language === 'en' ? 'Contact Information' : 'رابطے کی معلومات'}
              </h3>

              <div className="space-y-6">
                {[
                  { icon: Phone, label: language === 'en' ? 'Phone' : 'فون', value: currentContent.contact.phone },
                  { icon: Mail, label: language === 'en' ? 'Email' : 'ای میل', value: currentContent.contact.email },
                  { icon: MapPin, label: language === 'en' ? 'Address' : 'پتہ', value: currentContent.contact.address },
                  { icon: Clock, label: language === 'en' ? 'Hours' : 'اوقات', value: currentContent.contact.hours },
                ].map((item, index) => {
                  const Icon = item.icon;
                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={inView ? { opacity: 1, x: 0 } : {}}
                      transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
                      whileHover={{ scale: 1.02 }}
                      className="flex items-start space-x-4"
                    >
                      <div className="w-12 h-12 bg-gradient-to-r from-green-400 to-yellow-400 rounded-xl flex items-center justify-center flex-shrink-0">
                        <Icon className="w-6 h-6 text-black" />
                      </div>
                      <div>
                        <h4 className={`font-semibold mb-1 ${language === 'ur' ? 'font-urdu' : ''}`}>
                          {item.label}
                        </h4>
                        <p className={`${
                          theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
                        } ${language === 'ur' ? 'font-urdu' : ''}`}>
                          {item.value}
                        </p>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>

            {/* Map Placeholder */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.8 }}
              className={`h-64 rounded-3xl ${
                theme === 'dark' 
                  ? 'bg-gray-800/50 border border-white/10' 
                  : 'bg-gray-200 border border-gray-300'
              } flex items-center justify-center overflow-hidden`}
            >
              <div className="text-center">
                <MapPin className={`w-12 h-12 mx-auto mb-4 ${
                  theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                }`} />
                <p className={`${
                  theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                } ${language === 'ur' ? 'font-urdu' : ''}`}>
                  {language === 'en' ? 'Interactive Map' : 'انٹرایکٹو میپ'}
                </p>
              </div>
            </motion.div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className={`p-8 rounded-3xl ${
              theme === 'dark' 
                ? 'bg-white/5 border border-white/10' 
                : 'bg-white border border-gray-200'
            } backdrop-blur-md shadow-xl`}
          >
            {!isSubmitted ? (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className={`block text-sm font-medium mb-2 ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {currentContent.form.name}
                  </label>
                  <motion.input
                    whileFocus={{ scale: 1.02 }}
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-3 rounded-xl border ${
                      theme === 'dark' 
                        ? 'bg-white/10 border-white/20 text-white placeholder-gray-400' 
                        : 'bg-gray-50 border-gray-300 text-black placeholder-gray-500'
                    } focus:outline-none focus:ring-2 focus:ring-green-400 transition-all`}
                    placeholder={currentContent.form.name}
                    required
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${language === 'ur' ? 'font-urdu' : ''}`}>
                      {currentContent.form.email}
                    </label>
                    <motion.input
                      whileFocus={{ scale: 1.02 }}
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      className={`w-full px-4 py-3 rounded-xl border ${
                        theme === 'dark' 
                          ? 'bg-white/10 border-white/20 text-white placeholder-gray-400' 
                          : 'bg-gray-50 border-gray-300 text-black placeholder-gray-500'
                      } focus:outline-none focus:ring-2 focus:ring-green-400 transition-all`}
                      placeholder={currentContent.form.email}
                      required
                    />
                  </div>

                  <div>
                    <label className={`block text-sm font-medium mb-2 ${language === 'ur' ? 'font-urdu' : ''}`}>
                      {currentContent.form.phone}
                    </label>
                    <motion.input
                      whileFocus={{ scale: 1.02 }}
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className={`w-full px-4 py-3 rounded-xl border ${
                        theme === 'dark' 
                          ? 'bg-white/10 border-white/20 text-white placeholder-gray-400' 
                          : 'bg-gray-50 border-gray-300 text-black placeholder-gray-500'
                      } focus:outline-none focus:ring-2 focus:ring-green-400 transition-all`}
                      placeholder={currentContent.form.phone}
                    />
                  </div>
                </div>

                <div>
                  <label className={`block text-sm font-medium mb-2 ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {currentContent.form.service}
                  </label>
                  <motion.select
                    whileFocus={{ scale: 1.02 }}
                    name="service"
                    value={formData.service}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-3 rounded-xl border ${
                      theme === 'dark' 
                        ? 'bg-white/10 border-white/20 text-white' 
                        : 'bg-gray-50 border-gray-300 text-black'
                    } focus:outline-none focus:ring-2 focus:ring-green-400 transition-all ${language === 'ur' ? 'font-urdu' : ''}`}
                    required
                  >
                    <option value="">{currentContent.form.service}</option>
                    {currentContent.services.map((service, index) => (
                      <option key={index} value={service}>{service}</option>
                    ))}
                  </motion.select>
                </div>

                <div>
                  <label className={`block text-sm font-medium mb-2 ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {currentContent.form.message}
                  </label>
                  <motion.textarea
                    whileFocus={{ scale: 1.02 }}
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    rows={4}
                    className={`w-full px-4 py-3 rounded-xl border ${
                      theme === 'dark' 
                        ? 'bg-white/10 border-white/20 text-white placeholder-gray-400' 
                        : 'bg-gray-50 border-gray-300 text-black placeholder-gray-500'
                    } focus:outline-none focus:ring-2 focus:ring-green-400 transition-all resize-none`}
                    placeholder={currentContent.form.message}
                    required
                  />
                </div>

                <motion.button
                  whileHover={{ scale: 1.02, boxShadow: '0 20px 40px rgba(34, 197, 94, 0.3)' }}
                  whileTap={{ scale: 0.98 }}
                  type="submit"
                  className="w-full bg-gradient-to-r from-green-400 to-green-600 text-black font-semibold py-4 rounded-xl flex items-center justify-center space-x-2 shadow-lg"
                >
                  <Send size={20} />
                  <span className={language === 'ur' ? 'font-urdu' : ''}>{currentContent.form.submit}</span>
                </motion.button>
              </form>
            ) : (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-12"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
                  className="w-20 h-20 mx-auto mb-6 bg-gradient-to-r from-green-400 to-green-600 rounded-full flex items-center justify-center"
                >
                  <CheckCircle className="w-10 h-10 text-white" />
                </motion.div>
                <h3 className={`text-2xl font-bold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
                  {language === 'en' ? 'Message Sent!' : 'پیغام بھیج دیا گیا!'}
                </h3>
                <p className={`${
                  theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
                } ${language === 'ur' ? 'font-urdu' : ''}`}>
                  {currentContent.form.success}
                </p>
              </motion.div>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Contact;