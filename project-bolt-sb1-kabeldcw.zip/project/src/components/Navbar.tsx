import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Sun, 
  Lightbulb, 
  Shield, 
  Home, 
  Menu, 
  X,
  Moon,
  Globe
} from 'lucide-react';

interface NavbarProps {
  currentSite: string;
  setCurrentSite: (site: 'main' | 'solar' | 'lighting' | 'security' | 'appliances') => void;
  theme: 'dark' | 'light';
  toggleTheme: () => void;
  language: 'en' | 'ur';
  toggleLanguage: () => void;
}

const Navbar: React.FC<NavbarProps> = ({
  currentSite,
  setCurrentSite,
  theme,
  toggleTheme,
  language,
  toggleLanguage
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { key: 'main', label: language === 'en' ? 'Home' : 'گھر', icon: Home },
    { key: 'solar', label: language === 'en' ? 'Solar Solutions' : 'سولر حل', icon: Sun },
    { key: 'lighting', label: language === 'en' ? 'Smart Lighting' : 'اسمارٹ لائٹنگ', icon: Lightbulb },
    { key: 'security', label: language === 'en' ? 'Security Systems' : 'سیکورٹی سسٹم', icon: Shield },
    { key: 'appliances', label: language === 'en' ? 'Appliances' : 'آلات', icon: Home }
  ];

  const scrollToContact = () => {
    if (currentSite !== 'main') {
      setCurrentSite('main');
      setTimeout(() => {
        document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
      }, 600);
    } else {
      document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? `${theme === 'dark' ? 'bg-black/90' : 'bg-white/90'} backdrop-blur-md shadow-lg`
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="flex items-center space-x-2"
          >
            <div className="w-10 h-10 bg-gradient-to-r from-green-400 to-yellow-400 rounded-full flex items-center justify-center">
              <Sun className="w-6 h-6 text-black" />
            </div>
            <span className={`text-2xl font-bold bg-gradient-to-r from-green-400 to-yellow-400 bg-clip-text text-transparent`}>
              SolarTech
            </span>
          </motion.div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-8">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <motion.button
                  key={item.key}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setCurrentSite(item.key as any)}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
                    currentSite === item.key
                      ? 'bg-green-500/20 text-green-400'
                      : `${theme === 'dark' ? 'text-gray-300 hover:text-white' : 'text-gray-700 hover:text-black'} hover:bg-green-500/10`
                  }`}
                >
                  <Icon size={20} />
                  <span className={language === 'ur' ? 'font-urdu' : ''}>{item.label}</span>
                </motion.button>
              );
            })}
          </div>

          {/* Action Buttons */}
          <div className="hidden lg:flex items-center space-x-4">
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={toggleTheme}
              className={`p-2 rounded-full ${theme === 'dark' ? 'bg-gray-800 text-yellow-400' : 'bg-gray-200 text-gray-800'}`}
            >
              {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={toggleLanguage}
              className={`p-2 rounded-full flex items-center space-x-1 ${theme === 'dark' ? 'bg-gray-800 text-green-400' : 'bg-gray-200 text-gray-800'}`}
            >
              <Globe size={20} />
              <span className="text-sm font-bold">{language.toUpperCase()}</span>
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05, boxShadow: '0 0 20px rgba(34, 197, 94, 0.5)' }}
              whileTap={{ scale: 0.95 }}
              onClick={scrollToContact}
              className="bg-gradient-to-r from-green-400 to-green-600 text-black px-6 py-2 rounded-full font-semibold shadow-lg"
            >
              {language === 'en' ? 'Contact' : 'رابطہ'}
            </motion.button>
          </div>

          {/* Mobile Menu Button */}
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 rounded-md"
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </motion.button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className={`lg:hidden ${theme === 'dark' ? 'bg-black/95' : 'bg-white/95'} backdrop-blur-md rounded-lg mt-2 p-4`}
          >
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <motion.button
                  key={item.key}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    setCurrentSite(item.key as any);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center space-x-3 px-3 py-3 rounded-lg mb-2 transition-colors ${
                    currentSite === item.key
                      ? 'bg-green-500/20 text-green-400'
                      : `${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'} hover:bg-green-500/10`
                  }`}
                >
                  <Icon size={20} />
                  <span className={language === 'ur' ? 'font-urdu' : ''}>{item.label}</span>
                </motion.button>
              );
            })}
            
            <div className="flex items-center justify-between pt-4 border-t border-gray-700">
              <div className="flex items-center space-x-2">
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={toggleTheme}
                  className={`p-2 rounded-full ${theme === 'dark' ? 'bg-gray-800 text-yellow-400' : 'bg-gray-200 text-gray-800'}`}
                >
                  {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
                </motion.button>
                
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={toggleLanguage}
                  className={`p-2 rounded-full flex items-center space-x-1 ${theme === 'dark' ? 'bg-gray-800 text-green-400' : 'bg-gray-200 text-gray-800'}`}
                >
                  <Globe size={20} />
                  <span className="text-sm font-bold">{language.toUpperCase()}</span>
                </motion.button>
              </div>
              
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => {
                  scrollToContact();
                  setIsMobileMenuOpen(false);
                }}
                className="bg-gradient-to-r from-green-400 to-green-600 text-black px-4 py-2 rounded-full font-semibold"
              >
                {language === 'en' ? 'Contact' : 'رابطہ'}
              </motion.button>
            </div>
          </motion.div>
        )}
      </div>
    </motion.nav>
  );
};

export default Navbar;