import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Lightbulb, Smartphone, Wifi, Timer, Palette, Shield, Zap, Home } from 'lucide-react';

interface SmartLightingProps {
  theme: 'dark' | 'light';
  language: 'en' | 'ur';
}

const SmartLighting: React.FC<SmartLightingProps> = ({ theme, language }) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const content = {
    en: {
      hero: {
        title: "Smart Solar Lighting",
        subtitle: "Intelligent lighting solutions powered by solar energy",
        description: "Revolutionize your outdoor and indoor lighting with our advanced smart solar lighting systems. Control, schedule, and customize your lighting from anywhere.",
        cta: "Explore Smart Lights"
      },
      features: [
        {
          icon: Lightbulb,
          title: "Solar Powered",
          description: "100% solar energy with battery backup for uninterrupted lighting"
        },
        {
          icon: Smartphone,
          title: "Mobile Control",
          description: "Control lights remotely via smartphone app with intuitive interface"
        },
        {
          icon: Timer,
          title: "Smart Scheduling",
          description: "Automated on/off timers and daylight sensors for optimal efficiency"
        },
        {
          icon: Palette,
          title: "Color Changing",
          description: "RGB LED technology with millions of color combinations"
        }
      ],
      products: [
        {
          name: "SolarStreet Pro",
          image: "https://images.pexels.com/photos/416978/pexels-photo-416978.jpeg?auto=compress&cs=tinysrgb&w=800",
          features: ["50W LED", "Motion Sensor", "12hr Battery", "Weatherproof"],
          price: "$299"
        },
        {
          name: "GardenGlow Smart",
          image: "https://images.pexels.com/photos/1036936/pexels-photo-1036936.jpeg?auto=compress&cs=tinysrgb&w=800",
          features: ["RGB Colors", "Solar Panel", "Remote Control", "Decorative"],
          price: "$159"
        },
        {
          name: "FloodBeam Solar",
          image: "https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=800",
          features: ["100W Power", "Motion Detect", "All Weather", "Security"],
          price: "$399"
        }
      ]
    },
    ur: {
      hero: {
        title: "اسمارٹ سولر لائٹنگ",
        subtitle: "سولر انرجی سے چلنے والے ذہین لائٹنگ حل",
        description: "ہمارے جدید اسمارٹ سولر لائٹنگ سسٹم کے ساتھ اپنی بیرونی اور اندرونی لائٹنگ میں انقلاب لائیں۔ کہیں سے بھی اپنی لائٹنگ کو کنٹرول، شیڈول اور کسٹمائز کریں۔",
        cta: "اسمارٹ لائٹس دیکھیں"
      },
      features: [
        {
          icon: Lightbulb,
          title: "سولر پاورڈ",
          description: "مسلسل روشنی کے لیے بیٹری بیک اپ کے ساتھ 100% سولر انرجی"
        },
        {
          icon: Smartphone,
          title: "موبائل کنٹرول",
          description: "بدیہی انٹرفیس کے ساتھ اسمارٹ فون ایپ کے ذریعے لائٹس کو ریموٹ کنٹرول کریں"
        },
        {
          icon: Timer,
          title: "اسمارٹ شیڈولنگ",
          description: "بہترین کارکردگی کے لیے خودکار آن/آف ٹائمر اور ڈے لائٹ سینسر"
        },
        {
          icon: Palette,
          title: "رنگ تبدیل کرنا",
          description: "لاکھوں رنگ کے امتزاج کے ساتھ RGB LED ٹیکنالوجی"
        }
      ],
      products: [
        {
          name: "سولرسٹریٹ پرو",
          image: "https://images.pexels.com/photos/416978/pexels-photo-416978.jpeg?auto=compress&cs=tinysrgb&w=800",
          features: ["50W LED", "موشن سینسر", "12 گھنٹے بیٹری", "موسمی مزاحمت"],
          price: "$299"
        },
        {
          name: "گارڈن گلو اسمارٹ",
          image: "https://images.pexels.com/photos/1036936/pexels-photo-1036936.jpeg?auto=compress&cs=tinysrgb&w=800",
          features: ["RGB رنگ", "سولر پینل", "ریموٹ کنٹرول", "آرائشی"],
          price: "$159"
        },
        {
          name: "فلڈبیم سولر",
          image: "https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=800",
          features: ["100W پاور", "موشن ڈیٹکٹ", "تمام موسم", "سیکورٹی"],
          price: "$399"
        }
      ]
    }
  };

  const currentContent = content[language];

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 z-0">
          <div className={`w-full h-full ${
            theme === 'dark' 
              ? 'bg-gradient-to-br from-purple-900 via-blue-900 to-black' 
              : 'bg-gradient-to-br from-blue-100 via-purple-100 to-white'
          }`}>
            {/* Floating Light Orbs */}
            {[...Array(15)].map((_, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0 }}
                animate={{ 
                  opacity: [0, 1, 0],
                  scale: [0.5, 1.5, 0.5],
                  x: [0, Math.random() * 200 - 100],
                  y: [0, Math.random() * 200 - 100]
                }}
                transition={{
                  duration: Math.random() * 8 + 4,
                  repeat: Infinity,
                  delay: Math.random() * 3
                }}
                className="absolute w-4 h-4 bg-yellow-400 rounded-full blur-sm"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  filter: 'drop-shadow(0 0 10px rgba(255, 255, 0, 0.5))'
                }}
              />
            ))}
          </div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className={`text-center max-w-4xl mx-auto ${language === 'ur' ? 'rtl' : ''}`}
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={inView ? { scale: 1 } : {}}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="w-24 h-24 mx-auto mb-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center"
            >
              <Lightbulb className="w-12 h-12 text-white" />
            </motion.div>

            <h1 className={`text-5xl sm:text-6xl lg:text-7xl font-bold mb-6 ${language === 'ur' ? 'font-urdu' : ''}`}>
              <span className="bg-gradient-to-r from-yellow-400 via-orange-400 to-pink-400 bg-clip-text text-transparent">
                {currentContent.hero.title}
              </span>
            </h1>
            
            <p className={`text-2xl mb-8 ${
              theme === 'dark' ? 'text-gray-300' : 'text-gray-700'
            } ${language === 'ur' ? 'font-urdu' : ''}`}>
              {currentContent.hero.subtitle}
            </p>

            <p className={`text-lg mb-12 ${
              theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
            } max-w-3xl mx-auto leading-relaxed ${language === 'ur' ? 'font-urdu' : ''}`}>
              {currentContent.hero.description}
            </p>

            <motion.button
              whileHover={{ 
                scale: 1.05, 
                boxShadow: '0 20px 40px rgba(255, 193, 7, 0.3)' 
              }}
              whileTap={{ scale: 0.95 }}
              className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black px-8 py-4 rounded-full font-semibold text-lg flex items-center space-x-2 mx-auto shadow-2xl"
            >
              <span className={language === 'ur' ? 'font-urdu' : ''}>{currentContent.hero.cta}</span>
              <Lightbulb size={20} />
            </motion.button>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className={`py-20 ${theme === 'dark' ? 'bg-gray-900/50' : 'bg-gray-50'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className={`text-center mb-16 ${language === 'ur' ? 'rtl' : ''}`}
          >
            <h2 className={`text-4xl sm:text-5xl font-bold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
              {language === 'en' ? 'Smart Features' : 'اسمارٹ فیچرز'}
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
            {currentContent.features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  whileHover={{ scale: 1.05, y: -10 }}
                  className={`p-6 rounded-2xl ${
                    theme === 'dark' 
                      ? 'bg-black/30 border border-white/10' 
                      : 'bg-white border border-gray-200 shadow-lg'
                  } backdrop-blur-md text-center group`}
                >
                  <motion.div
                    whileHover={{ rotate: 10, scale: 1.1 }}
                    className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-2xl flex items-center justify-center"
                  >
                    <Icon className="w-8 h-8 text-white" />
                  </motion.div>
                  
                  <h3 className={`text-xl font-semibold mb-3 ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {feature.title}
                  </h3>
                  
                  <p className={`text-sm ${
                    theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                  } ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {feature.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className={`py-20 ${theme === 'dark' ? 'bg-black/50' : 'bg-white'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className={`text-center mb-16 ${language === 'ur' ? 'rtl' : ''}`}
          >
            <h2 className={`text-4xl sm:text-5xl font-bold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
              {language === 'en' ? 'Featured Products' : 'نمایاں پروڈکٹس'}
            </h2>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-8">
            {currentContent.products.map((product, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ scale: 1.02, y: -10 }}
                className={`rounded-3xl overflow-hidden ${
                  theme === 'dark' 
                    ? 'bg-white/5 border border-white/10' 
                    : 'bg-gray-50 border border-gray-200'
                } backdrop-blur-md shadow-xl group`}
              >
                <div className="relative overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  
                  <div className="absolute top-4 right-4 bg-yellow-400 text-black px-3 py-1 rounded-full text-sm font-semibold">
                    {product.price}
                  </div>
                </div>

                <div className="p-6">
                  <h3 className={`text-xl font-bold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {product.name}
                  </h3>

                  <div className="grid grid-cols-2 gap-3 mb-6">
                    {product.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center space-x-2">
                        <div className="w-2 h-2 rounded-full bg-gradient-to-r from-yellow-400 to-orange-500" />
                        <span className={`text-sm ${
                          theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
                        } ${language === 'ur' ? 'font-urdu' : ''}`}>
                          {feature}
                        </span>
                      </div>
                    ))}
                  </div>

                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-semibold py-3 rounded-xl shadow-lg"
                  >
                    <span className={language === 'ur' ? 'font-urdu' : ''}>
                      {language === 'en' ? 'Learn More' : 'مزید جانیں'}
                    </span>
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className={`py-20 ${theme === 'dark' ? 'bg-gray-900/30' : 'bg-gray-50'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className={language === 'ur' ? 'rtl' : ''}
            >
              <h3 className={`text-3xl font-bold mb-6 ${language === 'ur' ? 'font-urdu' : ''}`}>
                {language === 'en' ? 'Why Choose Smart Solar Lighting?' : 'اسمارٹ سولر لائٹنگ کیوں منتخب کریں؟'}
              </h3>
              
              <div className="space-y-6">
                {[
                  {
                    icon: Zap,
                    title: language === 'en' ? 'Energy Efficient' : 'توانائی کی بچت',
                    description: language === 'en' ? 'Save up to 90% on electricity bills' : 'بجلی کے بل میں 90% تک کی بچت'
                  },
                  {
                    icon: Shield,
                    title: language === 'en' ? 'Weather Resistant' : 'موسمی مزاحمت',
                    description: language === 'en' ? 'IP65 rating for all weather conditions' : 'تمام موسمی حالات کے لیے IP65 ریٹنگ'
                  },
                  {
                    icon: Wifi,
                    title: language === 'en' ? 'Smart Connectivity' : 'اسمارٹ کنیکٹویٹی',
                    description: language === 'en' ? 'WiFi and Bluetooth enabled controls' : 'WiFi اور بلوٹوتھ فعال کنٹرولز'
                  }
                ].map((benefit, index) => {
                  const Icon = benefit.icon;
                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      className="flex items-start space-x-4"
                    >
                      <div className="w-12 h-12 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-xl flex items-center justify-center flex-shrink-0">
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h4 className={`text-lg font-semibold mb-2 ${language === 'ur' ? 'font-urdu' : ''}`}>
                          {benefit.title}
                        </h4>
                        <p className={`${
                          theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
                        } ${language === 'ur' ? 'font-urdu' : ''}`}>
                          {benefit.description}
                        </p>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <div className={`aspect-square rounded-3xl ${
                theme === 'dark' 
                  ? 'bg-gradient-to-br from-yellow-400/20 to-orange-500/20' 
                  : 'bg-gradient-to-br from-yellow-100 to-orange-100'
              } flex items-center justify-center`}>
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                  className="w-48 h-48 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center"
                >
                  <Home className="w-24 h-24 text-white" />
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default SmartLighting;