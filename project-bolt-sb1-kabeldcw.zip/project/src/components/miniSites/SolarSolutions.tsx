import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Sun, Zap, Battery, Wrench, Award, Users, Target, ArrowRight } from 'lucide-react';

interface SolarSolutionsProps {
  theme: 'dark' | 'light';
  language: 'en' | 'ur';
}

const SolarSolutions: React.FC<SolarSolutionsProps> = ({ theme, language }) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const content = {
    en: {
      hero: {
        title: "Complete Solar Solutions",
        subtitle: "From design to installation, we handle everything",
        description: "Transform your energy consumption with our comprehensive solar solutions. We provide end-to-end services including consultation, design, installation, and maintenance.",
        cta: "Get Solar Quote"
      },
      solutions: [
        {
          icon: Sun,
          title: "Residential Solar",
          description: "Custom solar panel systems for homes with energy storage and smart monitoring.",
          features: ["Roof Assessment", "Custom Design", "Professional Installation", "24/7 Monitoring"],
          gradient: "from-yellow-400 to-orange-500"
        },
        {
          icon: Zap,
          title: "Commercial Solar",
          description: "Large-scale solar installations for businesses to reduce operational costs.",
          features: ["Energy Audit", "Financial Analysis", "Grid Integration", "Performance Guarantee"],
          gradient: "from-green-400 to-blue-500"
        },
        {
          icon: Battery,
          title: "Energy Storage",
          description: "Advanced battery systems for energy independence and backup power.",
          features: ["Battery Sizing", "Backup Systems", "Grid Integration", "Smart Management"],
          gradient: "from-purple-400 to-pink-500"
        },
        {
          icon: Wrench,
          title: "Maintenance",
          description: "Comprehensive maintenance services to ensure optimal performance.",
          features: ["Regular Inspections", "Performance Monitoring", "Cleaning Services", "Warranty Support"],
          gradient: "from-blue-400 to-cyan-500"
        }
      ],
      process: {
        title: "Our Process",
        steps: [
          { title: "Consultation", description: "Free energy assessment and site evaluation" },
          { title: "Design", description: "Custom system design based on your needs" },
          { title: "Installation", description: "Professional installation by certified technicians" },
          { title: "Activation", description: "System commissioning and performance testing" }
        ]
      },
      stats: [
        { value: "25K+", label: "Solar Installations" },
        { value: "500MW", label: "Total Capacity" },
        { value: "98%", label: "System Uptime" },
        { value: "15 Years", label: "Average Warranty" }
      ]
    },
    ur: {
      hero: {
        title: "مکمل سولر حل",
        subtitle: "ڈیزائن سے انسٹالیشن تک، ہم سب کچھ سنبھالتے ہیں",
        description: "ہمارے جامع سولر حلول کے ساتھ اپنی توانائی کی کھپت کو تبدیل کریں۔ ہم مشاورت، ڈیزائن، انسٹالیشن، اور دیکھ بھال سمیت مکمل خدمات فراہم کرتے ہیں۔",
        cta: "سولر کوٹیشن حاصل کریں"
      },
      solutions: [
        {
          icon: Sun,
          title: "رہائشی سولر",
          description: "انرجی اسٹوریج اور اسمارٹ مانیٹرنگ کے ساتھ گھروں کے لیے کسٹم سولر پینل سسٹم۔",
          features: ["چھت کا جائزہ", "کسٹم ڈیزائن", "پیشہ ورانہ انسٹالیشن", "24/7 نگرانی"],
          gradient: "from-yellow-400 to-orange-500"
        },
        {
          icon: Zap,
          title: "تجارتی سولر",
          description: "آپریشنل اخراجات کم کرنے کے لیے کاروبار کے لیے بڑے پیمانے کی سولر انسٹالیشن۔",
          features: ["انرجی آڈٹ", "مالی تجزیہ", "گرڈ انٹیگریشن", "کارکردگی کی ضمانت"],
          gradient: "from-green-400 to-blue-500"
        },
        {
          icon: Battery,
          title: "انرجی اسٹوریج",
          description: "توانائی کی آزادی اور بیک اپ پاور کے لیے جدید بیٹری سسٹم۔",
          features: ["بیٹری سائزنگ", "بیک اپ سسٹم", "گرڈ انٹیگریشن", "اسمارٹ مینجمنٹ"],
          gradient: "from-purple-400 to-pink-500"
        },
        {
          icon: Wrench,
          title: "دیکھ بھال",
          description: "بہترین کارکردگی کو یقینی بنانے کے لیے جامع دیکھ بھال کی خدمات۔",
          features: ["باقاعدگی سے معائنہ", "کارکردگی کی نگرانی", "صفائی کی خدمات", "وارنٹی سپورٹ"],
          gradient: "from-blue-400 to-cyan-500"
        }
      ],
      process: {
        title: "ہمارا عمل",
        steps: [
          { title: "مشاورت", description: "مفت انرجی اسیسمنٹ اور سائٹ کا جائزہ" },
          { title: "ڈیزائن", description: "آپ کی ضروریات کی بنیاد پر کسٹم سسٹم ڈیزائن" },
          { title: "انسٹالیشن", description: "تصدیق شدہ ٹیکنیشنز کے ذریعے پیشہ ورانہ انسٹالیشن" },
          { title: "فعال کرنا", description: "سسٹم کمیشننگ اور کارکردگی کی جانچ" }
        ]
      },
      stats: [
        { value: "25K+", label: "سولر انسٹالیشنز" },
        { value: "500MW", label: "کل صلاحیت" },
        { value: "98%", label: "سسٹم اپ ٹائم" },
        { value: "15 سال", label: "اوسط وارنٹی" }
      ]
    }
  };

  const currentContent = content[language];

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Video Background */}
        <div className="absolute inset-0 z-0">
          <video
            autoPlay
            loop
            muted
            playsInline
            className="w-full h-full object-cover"
          >
            <source src="https://videos.pexels.com/video-files/8941243/8941243-hd_1920_1080_25fps.mp4" type="video/mp4" />
          </video>
          <div className={`absolute inset-0 ${
            theme === 'dark' 
              ? 'bg-black/70 bg-gradient-to-r from-black/80 via-black/60 to-black/80' 
              : 'bg-white/30 bg-gradient-to-r from-white/50 via-white/30 to-white/50'
          }`}></div>
        </div>

        {/* Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className={`text-center max-w-4xl mx-auto ${language === 'ur' ? 'rtl' : ''}`}
          >
            <h1 className={`text-5xl sm:text-6xl lg:text-7xl font-bold mb-6 ${language === 'ur' ? 'font-urdu' : ''}`}>
              <span className="bg-gradient-to-r from-yellow-400 via-green-400 to-blue-400 bg-clip-text text-transparent">
                {currentContent.hero.title}
              </span>
            </h1>
            
            <p className={`text-2xl mb-8 ${
              theme === 'dark' ? 'text-gray-300' : 'text-gray-700'
            } ${language === 'ur' ? 'font-urdu' : ''}`}>
              {currentContent.hero.subtitle}
            </p>

            <p className={`text-lg mb-12 ${
              theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
            } max-w-3xl mx-auto leading-relaxed ${language === 'ur' ? 'font-urdu' : ''}`}>
              {currentContent.hero.description}
            </p>

            <motion.button
              whileHover={{ 
                scale: 1.05, 
                boxShadow: '0 20px 40px rgba(34, 197, 94, 0.3)' 
              }}
              whileTap={{ scale: 0.95 }}
              className="bg-gradient-to-r from-green-400 to-green-600 text-black px-8 py-4 rounded-full font-semibold text-lg flex items-center space-x-2 mx-auto shadow-2xl"
            >
              <span className={language === 'ur' ? 'font-urdu' : ''}>{currentContent.hero.cta}</span>
              <ArrowRight size={20} />
            </motion.button>
          </motion.div>
        </div>
      </section>

      {/* Solutions Grid */}
      <section className={`py-20 ${theme === 'dark' ? 'bg-gray-900/50' : 'bg-gray-50'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className={`text-center mb-16 ${language === 'ur' ? 'rtl' : ''}`}
          >
            <h2 className={`text-4xl sm:text-5xl font-bold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
              {language === 'en' ? 'Our Solar Solutions' : 'ہمارے سولر حل'}
            </h2>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-8 mb-20">
            {currentContent.solutions.map((solution, index) => {
              const Icon = solution.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  whileHover={{ scale: 1.02, y: -10 }}
                  className={`p-8 rounded-3xl ${
                    theme === 'dark' 
                      ? 'bg-black/30 border border-white/10' 
                      : 'bg-white border border-gray/10 shadow-lg'
                  } backdrop-blur-md relative overflow-hidden group`}
                >
                  {/* Background Gradient */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${solution.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-500`} />
                  
                  <div className="relative z-10">
                    <div className={`w-16 h-16 mb-6 rounded-2xl bg-gradient-to-br ${solution.gradient} flex items-center justify-center`}>
                      <Icon className="w-8 h-8 text-white" />
                    </div>

                    <h3 className={`text-2xl font-bold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
                      {solution.title}
                    </h3>
                    
                    <p className={`${
                      theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
                    } mb-6 leading-relaxed ${language === 'ur' ? 'font-urdu' : ''}`}>
                      {solution.description}
                    </p>

                    <div className="grid grid-cols-2 gap-3">
                      {solution.features.map((feature, featureIndex) => (
                        <div key={featureIndex} className="flex items-center space-x-2">
                          <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${solution.gradient}`} />
                          <span className={`text-sm ${
                            theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
                          } ${language === 'ur' ? 'font-urdu' : ''}`}>
                            {feature}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className={`py-20 ${theme === 'dark' ? 'bg-black/50' : 'bg-white'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className={`text-center mb-16 ${language === 'ur' ? 'rtl' : ''}`}
          >
            <h2 className={`text-4xl sm:text-5xl font-bold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
              {currentContent.process.title}
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-4 gap-8 mb-20">
            {currentContent.process.steps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="text-center relative"
              >
                <div className={`w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r from-green-400 to-yellow-400 flex items-center justify-center text-black font-bold text-2xl`}>
                  {index + 1}
                </div>
                <h3 className={`text-xl font-semibold mb-2 ${language === 'ur' ? 'font-urdu' : ''}`}>
                  {step.title}
                </h3>
                <p className={`text-sm ${
                  theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                } ${language === 'ur' ? 'font-urdu' : ''}`}>
                  {step.description}
                </p>
                
                {/* Connection Line */}
                {index < currentContent.process.steps.length - 1 && (
                  <div className={`hidden md:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-green-400 to-yellow-400 opacity-30`} />
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className={`py-20 ${theme === 'dark' ? 'bg-gray-900/30' : 'bg-gray-50'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {currentContent.stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className="text-center"
              >
                <div className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-green-400 to-yellow-400 bg-clip-text text-transparent mb-2">
                  {stat.value}
                </div>
                <div className={`text-sm ${
                  theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                } ${language === 'ur' ? 'font-urdu' : ''}`}>
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default SolarSolutions;