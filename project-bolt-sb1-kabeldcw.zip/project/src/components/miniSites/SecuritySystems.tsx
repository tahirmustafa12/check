import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Shield, Camera, Eye, Smartphone, Bell, Lock, Zap, Wifi } from 'lucide-react';

interface SecuritySystemsProps {
  theme: 'dark' | 'light';
  language: 'en' | 'ur';
}

const SecuritySystems: React.FC<SecuritySystemsProps> = ({ theme, language }) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const content = {
    en: {
      hero: {
        title: "Solar Security Systems",
        subtitle: "Advanced security powered by renewable energy",
        description: "Protect your property with our cutting-edge solar-powered security systems. Complete surveillance, motion detection, and smart alerts - all running on clean energy.",
        cta: "Secure Your Property"
      },
      features: [
        {
          icon: Camera,
          title: "HD Surveillance",
          description: "4K Ultra HD cameras with night vision and cloud storage"
        },
        {
          icon: Eye,
          title: "Motion Detection",
          description: "Advanced AI-powered motion sensing with instant alerts"
        },
        {
          icon: Smartphone,
          title: "Remote Monitoring",
          description: "24/7 access to your security system via mobile app"
        },
        {
          icon: Bell,
          title: "Instant Alerts",
          description: "Real-time notifications via SMS, email, and push notifications"
        }
      ],
      systems: [
        {
          name: "Guardian Pro",
          description: "Complete home security solution with multiple cameras and sensors",
          features: ["8 HD Cameras", "Motion Sensors", "Smart Alerts", "Cloud Storage"],
          coverage: "Up to 5000 sq ft",
          battery: "72 hours backup",
          price: "$1,299"
        },
        {
          name: "Perimeter Shield",
          description: "Advanced perimeter security for large properties and businesses",
          features: ["12 Cameras", "Thermal Detection", "AI Analytics", "Professional Monitoring"],
          coverage: "Up to 10,000 sq ft",
          battery: "96 hours backup",
          price: "$2,599"
        },
        {
          name: "Smart Guard",
          description: "Basic security package for small homes and offices",
          features: ["4 HD Cameras", "Basic Sensors", "Mobile App", "Local Storage"],
          coverage: "Up to 2000 sq ft",
          battery: "48 hours backup",
          price: "$699"
        }
      ]
    },
    ur: {
      hero: {
        title: "سولر سیکورٹی سسٹم",
        subtitle: "قابل تجدید توانائی سے چلنے والی جدید سیکورٹی",
        description: "ہمارے جدید سولر پاورڈ سیکورٹی سسٹم کے ساتھ اپنی املاک کی حفاظت کریں۔ مکمل نگرانی، موشن ڈیٹیکشن، اور اسمارٹ الرٹس - سب کچھ صاف توانائی پر چل رہا ہے۔",
        cta: "اپنی املاک محفوظ کریں"
      },
      features: [
        {
          icon: Camera,
          title: "HD نگرانی",
          description: "نائٹ ویژن اور کلاؤڈ اسٹوریج کے ساتھ 4K Ultra HD کیمرے"
        },
        {
          icon: Eye,
          title: "موشن ڈیٹیکشن",
          description: "فوری الرٹس کے ساتھ جدید AI-پاورڈ موشن سینسنگ"
        },
        {
          icon: Smartphone,
          title: "ریموٹ مانیٹرنگ",
          description: "موبائل ایپ کے ذریعے آپ کے سیکورٹی سسٹم تک 24/7 رسائی"
        },
        {
          icon: Bell,
          title: "فوری الرٹس",
          description: "SMS، ای میل، اور پش نوٹیفیکیشن کے ذریعے ریئل ٹائم اطلاعات"
        }
      ],
      systems: [
        {
          name: "گارڈین پرو",
          description: "متعدد کیمروں اور سینسرز کے ساتھ مکمل گھریلو سیکورٹی حل",
          features: ["8 HD کیمرے", "موشن سینسرز", "اسمارٹ الرٹس", "کلاؤڈ اسٹوریج"],
          coverage: "5000 مربع فٹ تک",
          battery: "72 گھنٹے بیک اپ",
          price: "$1,299"
        },
        {
          name: "پیری میٹر شیلڈ",
          description: "بڑی املاک اور کاروبار کے لیے جدید پیری میٹر سیکورٹی",
          features: ["12 کیمرے", "تھرمل ڈیٹیکشن", "AI تجزیات", "پیشہ ورانہ نگرانی"],
          coverage: "10,000 مربع فٹ تک",
          battery: "96 گھنٹے بیک اپ",
          price: "$2,599"
        },
        {
          name: "اسمارٹ گارڈ",
          description: "چھوٹے گھروں اور دفاتر کے لیے بنیادی سیکورٹی پیکج",
          features: ["4 HD کیمرے", "بنیادی سینسرز", "موبائل ایپ", "لوکل اسٹوریج"],
          coverage: "2000 مربع فٹ تک",
          battery: "48 گھنٹے بیک اپ",
          price: "$699"
        }
      ]
    }
  };

  const currentContent = content[language];

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Animated Security Grid Background */}
        <div className="absolute inset-0 z-0">
          <div className={`w-full h-full ${
            theme === 'dark' 
              ? 'bg-gradient-to-br from-red-900 via-gray-900 to-black' 
              : 'bg-gradient-to-br from-red-100 via-gray-100 to-white'
          }`}>
            {/* Security Grid Lines */}
            <svg className="absolute inset-0 w-full h-full opacity-20" viewBox="0 0 100 100">
              <defs>
                <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                  <path d="M 10 0 L 0 0 0 10" fill="none" stroke={theme === 'dark' ? '#ef4444' : '#dc2626'} strokeWidth="0.5"/>
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>

            {/* Scanning Effect */}
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: '100%' }}
              transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
              className={`absolute top-0 w-1 h-full ${
                theme === 'dark' ? 'bg-red-400' : 'bg-red-600'
              } opacity-60`}
              style={{
                boxShadow: theme === 'dark' 
                  ? '0 0 20px rgba(248, 113, 113, 0.6)' 
                  : '0 0 20px rgba(220, 38, 38, 0.6)'
              }}
            />
          </div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className={`text-center max-w-4xl mx-auto ${language === 'ur' ? 'rtl' : ''}`}
          >
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={inView ? { scale: 1, rotate: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="w-24 h-24 mx-auto mb-8 bg-gradient-to-r from-red-500 to-orange-500 rounded-full flex items-center justify-center"
            >
              <Shield className="w-12 h-12 text-white" />
            </motion.div>

            <h1 className={`text-5xl sm:text-6xl lg:text-7xl font-bold mb-6 ${language === 'ur' ? 'font-urdu' : ''}`}>
              <span className="bg-gradient-to-r from-red-400 via-orange-400 to-yellow-400 bg-clip-text text-transparent">
                {currentContent.hero.title}
              </span>
            </h1>
            
            <p className={`text-2xl mb-8 ${
              theme === 'dark' ? 'text-gray-300' : 'text-gray-700'
            } ${language === 'ur' ? 'font-urdu' : ''}`}>
              {currentContent.hero.subtitle}
            </p>

            <p className={`text-lg mb-12 ${
              theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
            } max-w-3xl mx-auto leading-relaxed ${language === 'ur' ? 'font-urdu' : ''}`}>
              {currentContent.hero.description}
            </p>

            <motion.button
              whileHover={{ 
                scale: 1.05, 
                boxShadow: '0 20px 40px rgba(239, 68, 68, 0.3)' 
              }}
              whileTap={{ scale: 0.95 }}
              className="bg-gradient-to-r from-red-500 to-orange-500 text-white px-8 py-4 rounded-full font-semibold text-lg flex items-center space-x-2 mx-auto shadow-2xl"
            >
              <span className={language === 'ur' ? 'font-urdu' : ''}>{currentContent.hero.cta}</span>
              <Shield size={20} />
            </motion.button>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className={`py-20 ${theme === 'dark' ? 'bg-gray-900/50' : 'bg-gray-50'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className={`text-center mb-16 ${language === 'ur' ? 'rtl' : ''}`}
          >
            <h2 className={`text-4xl sm:text-5xl font-bold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
              {language === 'en' ? 'Security Features' : 'سیکورٹی فیچرز'}
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
            {currentContent.features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  whileHover={{ scale: 1.05, y: -10 }}
                  className={`p-6 rounded-2xl ${
                    theme === 'dark' 
                      ? 'bg-black/30 border border-red-500/20' 
                      : 'bg-white border border-gray-200 shadow-lg'
                  } backdrop-blur-md text-center group relative overflow-hidden`}
                >
                  {/* Subtle glow effect */}
                  <div className="absolute inset-0 bg-gradient-to-br from-red-500/5 to-orange-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  
                  <motion.div
                    whileHover={{ rotate: 10, scale: 1.1 }}
                    className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-red-500 to-orange-500 rounded-2xl flex items-center justify-center relative z-10"
                  >
                    <Icon className="w-8 h-8 text-white" />
                  </motion.div>
                  
                  <h3 className={`text-xl font-semibold mb-3 relative z-10 ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {feature.title}
                  </h3>
                  
                  <p className={`text-sm ${
                    theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                  } relative z-10 ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {feature.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Security Systems */}
      <section className={`py-20 ${theme === 'dark' ? 'bg-black/50' : 'bg-white'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className={`text-center mb-16 ${language === 'ur' ? 'rtl' : ''}`}
          >
            <h2 className={`text-4xl sm:text-5xl font-bold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
              {language === 'en' ? 'Security Packages' : 'سیکورٹی پیکیجز'}
            </h2>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-8">
            {currentContent.systems.map((system, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ scale: 1.02, y: -10 }}
                className={`p-8 rounded-3xl ${
                  theme === 'dark' 
                    ? 'bg-gradient-to-br from-gray-900/80 to-black/80 border border-red-500/20' 
                    : 'bg-gradient-to-br from-gray-50 to-white border border-gray-200'
                } backdrop-blur-md shadow-xl group relative overflow-hidden ${
                  index === 1 ? 'lg:scale-105 lg:shadow-2xl' : ''
                }`}
              >
                {/* Premium Badge for middle package */}
                {index === 1 && (
                  <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <div className="bg-gradient-to-r from-red-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm font-semibold">
                      {language === 'en' ? 'Most Popular' : 'سب سے زیادہ مقبول'}
                    </div>
                  </div>
                )}

                {/* Background glow */}
                <div className={`absolute inset-0 bg-gradient-to-br from-red-500/10 to-orange-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
                
                <div className="relative z-10">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className={`text-2xl font-bold ${language === 'ur' ? 'font-urdu' : ''}`}>
                      {system.name}
                    </h3>
                    <div className="text-3xl font-bold bg-gradient-to-r from-red-500 to-orange-500 bg-clip-text text-transparent">
                      {system.price}
                    </div>
                  </div>

                  <p className={`${
                    theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
                  } mb-6 ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {system.description}
                  </p>

                  {/* Features */}
                  <div className="space-y-3 mb-6">
                    {system.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center space-x-3">
                        <div className="w-2 h-2 rounded-full bg-gradient-to-r from-red-500 to-orange-500" />
                        <span className={`text-sm ${
                          theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
                        } ${language === 'ur' ? 'font-urdu' : ''}`}>
                          {feature}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Specs */}
                  <div className={`grid grid-cols-2 gap-4 p-4 rounded-2xl ${
                    theme === 'dark' ? 'bg-white/5' : 'bg-gray-100'
                  } border ${theme === 'dark' ? 'border-white/10' : 'border-gray-200'} mb-6`}>
                    <div className="text-center">
                      <div className="text-sm font-semibold bg-gradient-to-r from-red-500 to-orange-500 bg-clip-text text-transparent">
                        {system.coverage}
                      </div>
                      <div className={`text-xs ${
                        theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                      } ${language === 'ur' ? 'font-urdu' : ''}`}>
                        {language === 'en' ? 'Coverage' : 'کوریج'}
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="text-sm font-semibold bg-gradient-to-r from-red-500 to-orange-500 bg-clip-text text-transparent">
                        {system.battery}
                      </div>
                      <div className={`text-xs ${
                        theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                      } ${language === 'ur' ? 'font-urdu' : ''}`}>
                        {language === 'en' ? 'Battery' : 'بیٹری'}
                      </div>
                    </div>
                  </div>

                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full bg-gradient-to-r from-red-500 to-orange-500 text-white font-semibold py-3 rounded-xl shadow-lg"
                  >
                    <span className={language === 'ur' ? 'font-urdu' : ''}>
                      {language === 'en' ? 'Get Quote' : 'کوٹیشن حاصل کریں'}
                    </span>
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Technology Section */}
      <section className={`py-20 ${theme === 'dark' ? 'bg-gray-900/30' : 'bg-gray-50'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className={language === 'ur' ? 'rtl' : ''}
            >
              <h3 className={`text-3xl font-bold mb-6 ${language === 'ur' ? 'font-urdu' : ''}`}>
                {language === 'en' ? 'Advanced Security Technology' : 'جدید سیکورٹی ٹیکنالوجی'}
              </h3>
              
              <div className="space-y-6">
                {[
                  {
                    icon: Zap,
                    title: language === 'en' ? 'Solar Powered' : 'سولر پاورڈ',
                    description: language === 'en' ? '100% renewable energy with backup battery systems' : '100% قابل تجدید توانائی بیک اپ بیٹری سسٹم کے ساتھ'
                  },
                  {
                    icon: Wifi,
                    title: language === 'en' ? 'Wireless Connectivity' : 'وائرلیس کنیکٹویٹی',
                    description: language === 'en' ? 'WiFi, 4G, and satellite connectivity options' : 'WiFi، 4G، اور سیٹلائٹ کنیکٹویٹی آپشنز'
                  },
                  {
                    icon: Lock,
                    title: language === 'en' ? 'Encrypted Data' : 'خفیہ ڈیٹا',
                    description: language === 'en' ? 'Military-grade encryption for all data transmission' : 'تمام ڈیٹا ٹرانسمیشن کے لیے ملٹری گریڈ انکرپشن'
                  }
                ].map((tech, index) => {
                  const Icon = tech.icon;
                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      className="flex items-start space-x-4"
                    >
                      <div className="w-12 h-12 bg-gradient-to-r from-red-500 to-orange-500 rounded-xl flex items-center justify-center flex-shrink-0">
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h4 className={`text-lg font-semibold mb-2 ${language === 'ur' ? 'font-urdu' : ''}`}>
                          {tech.title}
                        </h4>
                        <p className={`${
                          theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
                        } ${language === 'ur' ? 'font-urdu' : ''}`}>
                          {tech.description}
                        </p>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <div className={`aspect-square rounded-3xl ${
                theme === 'dark' 
                  ? 'bg-gradient-to-br from-red-500/20 to-orange-500/20' 
                  : 'bg-gradient-to-br from-red-100 to-orange-100'
              } flex items-center justify-center relative overflow-hidden`}>
                {/* Animated security radar */}
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-0"
                >
                  <div className={`absolute top-1/2 left-1/2 w-48 h-0.5 ${
                    theme === 'dark' ? 'bg-red-400' : 'bg-red-600'
                  } origin-left transform -translate-y-0.5`}
                    style={{
                      background: `linear-gradient(to right, ${
                        theme === 'dark' ? 'rgba(248, 113, 113, 0.8)' : 'rgba(220, 38, 38, 0.8)'
                      }, transparent)`
                    }}
                  />
                </motion.div>

                {/* Security dots */}
                {[...Array(8)].map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ scale: 0 }}
                    animate={{ scale: [0, 1, 0] }}
                    transition={{ duration: 2, repeat: Infinity, delay: i * 0.25 }}
                    className="absolute w-4 h-4 bg-red-500 rounded-full"
                    style={{
                      top: `${50 + 30 * Math.sin(i * Math.PI / 4)}%`,
                      left: `${50 + 30 * Math.cos(i * Math.PI / 4)}%`,
                      transform: 'translate(-50%, -50%)'
                    }}
                  />
                ))}

                <div className="w-24 h-24 bg-gradient-to-r from-red-500 to-orange-500 rounded-full flex items-center justify-center">
                  <Shield className="w-12 h-12 text-white" />
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default SecuritySystems;