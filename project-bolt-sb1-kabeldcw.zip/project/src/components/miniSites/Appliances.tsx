import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Home, Thermometer, Fan, Droplets, Zap, Leaf, Star, ChevronRight } from 'lucide-react';

interface AppliancesProps {
  theme: 'dark' | 'light';
  language: 'en' | 'ur';
}

const Appliances: React.FC<AppliancesProps> = ({ theme, language }) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const [activeCategory, setActiveCategory] = useState(0);

  const content = {
    en: {
      hero: {
        title: "Solar Home Appliances",
        subtitle: "Energy-efficient appliances powered by the sun",
        description: "Transform your home with our comprehensive range of solar-powered appliances. From air conditioners to water heaters, enjoy modern comfort while reducing your carbon footprint.",
        cta: "Shop Solar Appliances"
      },
      categories: [
        {
          name: "Air Conditioners",
          icon: Fan,
          products: [
            {
              name: "SolarCool AC 1.5 Ton",
              image: "https://images.pexels.com/photos/6489078/pexels-photo-6489078.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.8,
              price: "$1,299",
              features: ["Inverter Technology", "5 Star Rating", "Smart Controls", "Solar Compatible"],
              specs: { capacity: "1.5 Ton", energy: "5 Star", warranty: "5 Years" }
            },
            {
              name: "EcoBreeze Solar AC 2 Ton",
              image: "https://images.pexels.com/photos/7031720/pexels-photo-7031720.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.9,
              price: "$1,799",
              features: ["Dual Inverter", "Wi-Fi Control", "Energy Saving", "Quiet Operation"],
              specs: { capacity: "2 Ton", energy: "5 Star", warranty: "7 Years" }
            }
          ]
        },
        {
          name: "Water Heaters",
          icon: Droplets,
          products: [
            {
              name: "SolarHeat 200L System",
              image: "https://images.pexels.com/photos/8093967/pexels-photo-8093967.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.7,
              price: "$899",
              features: ["200L Capacity", "Vacuum Tubes", "Auto Temperature", "Frost Protection"],
              specs: { capacity: "200L", type: "Vacuum Tube", warranty: "10 Years" }
            },
            {
              name: "AquaSolar Pro 300L",
              image: "https://images.pexels.com/photos/7512042/pexels-photo-7512042.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.6,
              price: "$1,199",
              features: ["300L Tank", "Flat Plate", "Digital Display", "Backup Heating"],
              specs: { capacity: "300L", type: "Flat Plate", warranty: "12 Years" }
            }
          ]
        },
        {
          name: "Refrigerators",
          icon: Thermometer,
          products: [
            {
              name: "SolarFridge 300L",
              image: "https://images.pexels.com/photos/4686821/pexels-photo-4686821.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.5,
              price: "$1,599",
              features: ["DC Operation", "Energy Efficient", "Large Capacity", "Digital Controls"],
              specs: { capacity: "300L", energy: "A+++", warranty: "5 Years" }
            },
            {
              name: "EcoFrost Solar 450L",
              image: "https://images.pexels.com/photos/2343468/pexels-photo-2343468.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.4,
              price: "$2,199",
              features: ["Double Door", "Frost Free", "Smart Cooling", "Solar Compatible"],
              specs: { capacity: "450L", energy: "A++", warranty: "7 Years" }
            }
          ]
        }
      ],
      benefits: [
        {
          icon: Leaf,
          title: "Eco-Friendly",
          description: "Reduce carbon footprint by up to 80% compared to grid-powered appliances"
        },
        {
          icon: Zap,
          title: "Energy Savings",
          description: "Save up to 90% on electricity bills with solar-powered operation"
        },
        {
          icon: Home,
          title: "Smart Integration",
          description: "Seamlessly integrate with your existing solar power system"
        }
      ]
    },
    ur: {
      hero: {
        title: "سولر گھریلو آلات",
        subtitle: "سورج سے چلنے والے توانائی کی بچت کرنے والے آلات",
        description: "سولر سے چلنے والے آلات کی ہماری جامع رینج کے ساتھ اپنے گھر کو تبدیل کریں۔ ایئر کنڈیشنرز سے لے کر واٹر ہیٹرز تک، اپنے کاربن فوٹ پرنٹ کو کم کرتے ہوئے جدید آرام سے لطف اندوز ہوں۔",
        cta: "سولر آلات خریدیں"
      },
      categories: [
        {
          name: "ایئر کنڈیشنرز",
          icon: Fan,
          products: [
            {
              name: "سولرکول AC 1.5 ٹن",
              image: "https://images.pexels.com/photos/6489078/pexels-photo-6489078.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.8,
              price: "$1,299",
              features: ["انورٹر ٹیکنالوجی", "5 سٹار ریٹنگ", "اسمارٹ کنٹرولز", "سولر کمپیٹیبل"],
              specs: { capacity: "1.5 ٹن", energy: "5 سٹار", warranty: "5 سال" }
            },
            {
              name: "ایکوبریز سولر AC 2 ٹن",
              image: "https://images.pexels.com/photos/7031720/pexels-photo-7031720.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.9,
              price: "$1,799",
              features: ["ڈوئل انورٹر", "Wi-Fi کنٹرول", "توانائی کی بچت", "خاموش آپریشن"],
              specs: { capacity: "2 ٹن", energy: "5 سٹار", warranty: "7 سال" }
            }
          ]
        },
        {
          name: "واٹر ہیٹرز",
          icon: Droplets,
          products: [
            {
              name: "سولرہیٹ 200L سسٹم",
              image: "https://images.pexels.com/photos/8093967/pexels-photo-8093967.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.7,
              price: "$899",
              features: ["200L گنجائش", "ویکیوم ٹیوب", "خودکار درجہ حرارت", "برف کی حفاظت"],
              specs: { capacity: "200L", type: "ویکیوم ٹیوب", warranty: "10 سال" }
            },
            {
              name: "ایکواسولر پرو 300L",
              image: "https://images.pexels.com/photos/7512042/pexels-photo-7512042.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.6,
              price: "$1,199",
              features: ["300L ٹینک", "فلیٹ پلیٹ", "ڈیجیٹل ڈسپلے", "بیک اپ ہیٹنگ"],
              specs: { capacity: "300L", type: "فلیٹ پلیٹ", warranty: "12 سال" }
            }
          ]
        },
        {
          name: "ریفریجریٹرز",
          icon: Thermometer,
          products: [
            {
              name: "سولرفرج 300L",
              image: "https://images.pexels.com/photos/4686821/pexels-photo-4686821.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.5,
              price: "$1,599",
              features: ["DC آپریشن", "توانائی کی بچت", "بڑی گنجائش", "ڈیجیٹل کنٹرولز"],
              specs: { capacity: "300L", energy: "A+++", warranty: "5 سال" }
            },
            {
              name: "ایکوفراسٹ سولر 450L",
              image: "https://images.pexels.com/photos/2343468/pexels-photo-2343468.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.4,
              price: "$2,199",
              features: ["ڈبل ڈور", "فراسٹ فری", "اسمارٹ کولنگ", "سولر کمپیٹیبل"],
              specs: { capacity: "450L", energy: "A++", warranty: "7 سال" }
            }
          ]
        }
      ],
      benefits: [
        {
          icon: Leaf,
          title: "ماحول دوست",
          description: "گرڈ پاورڈ آلات کے مقابلے میں کاربن فوٹ پرنٹ میں 80% تک کمی"
        },
        {
          icon: Zap,
          title: "توانائی کی بچت",
          description: "سولر پاورڈ آپریشن کے ساتھ بجلی کے بلوں میں 90% تک کی بچت"
        },
        {
          icon: Home,
          title: "اسمارٹ انٹیگریشن",
          description: "آپ کے موجودہ سولر پاور سسٹم کے ساتھ آسان انٹیگریشن"
        }
      ]
    }
  };

  const currentContent = content[language];

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 z-0">
          <div className={`w-full h-full ${
            theme === 'dark' 
              ? 'bg-gradient-to-br from-blue-900 via-green-900 to-black' 
              : 'bg-gradient-to-br from-blue-100 via-green-100 to-white'
          }`}>
            {/* Floating Appliance Icons */}
            {[Fan, Droplets, Thermometer, Home, Zap].map((Icon, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 100 }}
                animate={{ 
                  opacity: [0, 0.6, 0],
                  y: [100, -100, -200],
                  rotate: [0, 180, 360]
                }}
                transition={{
                  duration: Math.random() * 10 + 8,
                  repeat: Infinity,
                  delay: Math.random() * 5
                }}
                className="absolute"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`
                }}
              >
                <Icon className={`w-8 h-8 ${theme === 'dark' ? 'text-green-400/30' : 'text-green-600/30'}`} />
              </motion.div>
            ))}
          </div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className={`text-center max-w-4xl mx-auto ${language === 'ur' ? 'rtl' : ''}`}
          >
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={inView ? { scale: 1, rotate: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="w-24 h-24 mx-auto mb-8 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center"
            >
              <Home className="w-12 h-12 text-white" />
            </motion.div>

            <h1 className={`text-5xl sm:text-6xl lg:text-7xl font-bold mb-6 ${language === 'ur' ? 'font-urdu' : ''}`}>
              <span className="bg-gradient-to-r from-blue-400 via-green-400 to-teal-400 bg-clip-text text-transparent">
                {currentContent.hero.title}
              </span>
            </h1>
            
            <p className={`text-2xl mb-8 ${
              theme === 'dark' ? 'text-gray-300' : 'text-gray-700'
            } ${language === 'ur' ? 'font-urdu' : ''}`}>
              {currentContent.hero.subtitle}
            </p>

            <p className={`text-lg mb-12 ${
              theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
            } max-w-3xl mx-auto leading-relaxed ${language === 'ur' ? 'font-urdu' : ''}`}>
              {currentContent.hero.description}
            </p>

            <motion.button
              whileHover={{ 
                scale: 1.05, 
                boxShadow: '0 20px 40px rgba(34, 197, 94, 0.3)' 
              }}
              whileTap={{ scale: 0.95 }}
              className="bg-gradient-to-r from-blue-500 to-green-500 text-white px-8 py-4 rounded-full font-semibold text-lg flex items-center space-x-2 mx-auto shadow-2xl"
            >
              <span className={language === 'ur' ? 'font-urdu' : ''}>{currentContent.hero.cta}</span>
              <ChevronRight size={20} />
            </motion.button>
          </motion.div>
        </div>
      </section>

      {/* Categories Section */}
      <section className={`py-20 ${theme === 'dark' ? 'bg-gray-900/50' : 'bg-gray-50'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className={`text-center mb-16 ${language === 'ur' ? 'rtl' : ''}`}
          >
            <h2 className={`text-4xl sm:text-5xl font-bold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
              {language === 'en' ? 'Solar Appliances' : 'سولر آلات'}
            </h2>
          </motion.div>

          {/* Category Tabs */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {currentContent.categories.map((category, index) => {
              const Icon = category.icon;
              return (
                <motion.button
                  key={index}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setActiveCategory(index)}
                  className={`flex items-center space-x-3 px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                    activeCategory === index
                      ? 'bg-gradient-to-r from-blue-500 to-green-500 text-white shadow-lg'
                      : theme === 'dark'
                        ? 'bg-white/10 text-gray-300 hover:bg-white/20'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  } ${language === 'ur' ? 'font-urdu' : ''}`}
                >
                  <Icon size={20} />
                  <span>{category.name}</span>
                </motion.button>
              );
            })}
          </div>

          {/* Products Grid */}
          <AnimatePresence mode="wait">
            <motion.div
              key={activeCategory}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="grid md:grid-cols-2 gap-8"
            >
              {currentContent.categories[activeCategory].products.map((product, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  whileHover={{ scale: 1.02, y: -10 }}
                  className={`rounded-3xl overflow-hidden ${
                    theme === 'dark' 
                      ? 'bg-white/5 border border-white/10' 
                      : 'bg-white border border-gray-200'
                  } backdrop-blur-md shadow-xl group`}
                >
                  <div className="relative overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    
                    <div className="absolute top-4 left-4 bg-blue-500 text-white px-3 py-1 rounded-full text-sm font-semibold flex items-center space-x-1">
                      <Star className="w-4 h-4 fill-current" />
                      <span>{product.rating}</span>
                    </div>

                    <div className="absolute top-4 right-4 bg-black/30 backdrop-blur-md text-white px-3 py-1 rounded-full text-sm font-semibold">
                      {product.price}
                    </div>
                  </div>

                  <div className="p-6">
                    <h3 className={`text-xl font-bold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
                      {product.name}
                    </h3>

                    <div className="space-y-2 mb-6">
                      {product.features.map((feature, featureIndex) => (
                        <div key={featureIndex} className="flex items-center space-x-2">
                          <div className="w-2 h-2 rounded-full bg-gradient-to-r from-blue-500 to-green-500" />
                          <span className={`text-sm ${
                            theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
                          } ${language === 'ur' ? 'font-urdu' : ''}`}>
                            {feature}
                          </span>
                        </div>
                      ))}
                    </div>

                    <div className={`grid grid-cols-3 gap-4 p-4 rounded-2xl ${
                      theme === 'dark' ? 'bg-white/5' : 'bg-gray-50'
                    } border ${theme === 'dark' ? 'border-white/10' : 'border-gray-200'} mb-6`}>
                      {Object.entries(product.specs).map(([key, value], specIndex) => (
                        <div key={specIndex} className="text-center">
                          <div className="text-sm font-bold bg-gradient-to-r from-blue-500 to-green-500 bg-clip-text text-transparent">
                            {value}
                          </div>
                          <div className={`text-xs ${
                            theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                          } uppercase tracking-wide ${language === 'ur' ? 'font-urdu' : ''}`}>
                            {key}
                          </div>
                        </div>
                      ))}
                    </div>

                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className="w-full bg-gradient-to-r from-blue-500 to-green-500 text-white font-semibold py-3 rounded-xl shadow-lg"
                    >
                      <span className={language === 'ur' ? 'font-urdu' : ''}>
                        {language === 'en' ? 'View Details' : 'تفصیلات دیکھیں'}
                      </span>
                    </motion.button>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </AnimatePresence>
        </div>
      </section>

      {/* Benefits Section */}
      <section className={`py-20 ${theme === 'dark' ? 'bg-black/50' : 'bg-white'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className={`text-center mb-16 ${language === 'ur' ? 'rtl' : ''}`}
          >
            <h2 className={`text-4xl sm:text-5xl font-bold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
              {language === 'en' ? 'Why Choose Solar Appliances?' : 'سولر آلات کیوں منتخب کریں؟'}
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {currentContent.benefits.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  whileHover={{ scale: 1.05, y: -5 }}
                  className={`p-8 rounded-2xl ${
                    theme === 'dark' 
                      ? 'bg-white/5 border border-white/10' 
                      : 'bg-gray-50 border border-gray-200'
                  } backdrop-blur-md text-center group`}
                >
                  <motion.div
                    whileHover={{ rotate: 10, scale: 1.1 }}
                    className="w-16 h-16 mx-auto mb-6 bg-gradient-to-r from-blue-500 to-green-500 rounded-2xl flex items-center justify-center"
                  >
                    <Icon className="w-8 h-8 text-white" />
                  </motion.div>
                  
                  <h3 className={`text-xl font-semibold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {benefit.title}
                  </h3>
                  
                  <p className={`${
                    theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                  } ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {benefit.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Appliances;