import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Home, Building2, Factory, Zap, Battery, Wrench } from 'lucide-react';

interface ServicesProps {
  theme: 'dark' | 'light';
  language: 'en' | 'ur';
}

const Services: React.FC<ServicesProps> = ({ theme, language }) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const content = {
    en: {
      title: "Our Services",
      subtitle: "Comprehensive Solar Solutions for Every Need",
      services: [
        {
          icon: Home,
          title: "Residential Solar",
          description: "Custom solar solutions for homes with premium panels and smart monitoring systems.",
          features: ["Roof Assessment", "Custom Design", "Installation", "Monitoring"],
          gradient: "from-blue-500 to-cyan-500"
        },
        {
          icon: Building2,
          title: "Commercial Solar",
          description: "Large-scale solar installations for businesses to reduce operational costs significantly.",
          features: ["Energy Audit", "ROI Analysis", "Maintenance", "Support"],
          gradient: "from-green-500 to-emerald-500"
        },
        {
          icon: Factory,
          title: "Industrial Solutions",
          description: "High-capacity solar systems for manufacturing and industrial facilities.",
          features: ["Load Analysis", "Grid Integration", "Scalability", "Compliance"],
          gradient: "from-orange-500 to-yellow-500"
        }
      ],
      additionalServices: [
        {
          icon: Battery,
          title: "Energy Storage",
          description: "Advanced battery systems for energy independence"
        },
        {
          icon: Zap,
          title: "Grid Integration",
          description: "Seamless connection to existing power infrastructure"
        },
        {
          icon: Wrench,
          title: "Maintenance",
          description: "24/7 support and preventive maintenance services"
        }
      ]
    },
    ur: {
      title: "ہماری خدمات",
      subtitle: "ہر ضرورت کے لیے جامع سولر حل",
      services: [
        {
          icon: Home,
          title: "رہائشی سولر",
          description: "پریمیم پینلز اور اسمارٹ مانیٹرنگ سسٹم کے ساتھ گھروں کے لیے کسٹم سولر حل۔",
          features: ["چھت کا جائزہ", "کسٹم ڈیزائن", "تنصیب", "نگرانی"],
          gradient: "from-blue-500 to-cyan-500"
        },
        {
          icon: Building2,
          title: "تجارتی سولر",
          description: "کاروباری اخراجات کو نمایاں طور پر کم کرنے کے لیے بڑے پیمانے پر سولر تنصیبات۔",
          features: ["انرجی آڈٹ", "منافع کا تجزیہ", "دیکھ بھال", "سپورٹ"],
          gradient: "from-green-500 to-emerald-500"
        },
        {
          icon: Factory,
          title: "صنعتی حل",
          description: "مینوفیکچرنگ اور صنعتی سہولات کے لیے اعلیٰ صلاحیت کے سولر سسٹم۔",
          features: ["لوڈ تجزیہ", "گرڈ انٹیگریشن", "توسیع پذیری", "تعمیل"],
          gradient: "from-orange-500 to-yellow-500"
        }
      ],
      additionalServices: [
        {
          icon: Battery,
          title: "انرجی اسٹوریج",
          description: "توانائی کی آزادی کے لیے جدید بیٹری سسٹم"
        },
        {
          icon: Zap,
          title: "گرڈ انٹیگریشن",
          description: "موجودہ بجلی کے بنیادی ڈھانچے سے بغیر رکاوٹ کنکشن"
        },
        {
          icon: Wrench,
          title: "دیکھ بھال",
          description: "24/7 سپورٹ اور احتیاطی دیکھ بھال کی خدمات"
        }
      ]
    }
  };

  const currentContent = content[language];

  return (
    <section id="services" className={`py-20 ${theme === 'dark' ? 'bg-gray-900/50' : 'bg-gray-50'}`} ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className={`text-center mb-16 ${language === 'ur' ? 'rtl' : ''}`}
        >
          <h2 className={`text-4xl sm:text-5xl font-bold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
            <span className="bg-gradient-to-r from-green-400 to-yellow-400 bg-clip-text text-transparent">
              {currentContent.title}
            </span>
          </h2>
          <p className={`text-xl ${
            theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
          } max-w-3xl mx-auto ${language === 'ur' ? 'font-urdu' : ''}`}>
            {currentContent.subtitle}
          </p>
        </motion.div>

        {/* Main Services Grid */}
        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {currentContent.services.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                whileHover={{ 
                  scale: 1.02, 
                  y: -10,
                  boxShadow: theme === 'dark' 
                    ? '0 25px 50px rgba(0, 0, 0, 0.5)' 
                    : '0 25px 50px rgba(0, 0, 0, 0.1)'
                }}
                className={`p-8 rounded-3xl ${
                  theme === 'dark' 
                    ? 'bg-black/30 border border-white/10' 
                    : 'bg-white border border-gray/10 shadow-lg'
                } backdrop-blur-md relative overflow-hidden group`}
              >
                {/* Background Gradient */}
                <div className={`absolute inset-0 bg-gradient-to-br ${service.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-500`} />
                
                {/* Icon */}
                <motion.div
                  whileHover={{ rotate: 10, scale: 1.1 }}
                  className={`w-16 h-16 mb-6 rounded-2xl bg-gradient-to-br ${service.gradient} flex items-center justify-center`}
                >
                  <Icon className="w-8 h-8 text-white" />
                </motion.div>

                <h3 className={`text-2xl font-bold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
                  {service.title}
                </h3>
                
                <p className={`${
                  theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
                } mb-6 leading-relaxed ${language === 'ur' ? 'font-urdu' : ''}`}>
                  {service.description}
                </p>

                {/* Features List */}
                <div className="space-y-3">
                  {service.features.map((feature, featureIndex) => (
                    <motion.div
                      key={featureIndex}
                      initial={{ opacity: 0, x: -20 }}
                      animate={inView ? { opacity: 1, x: 0 } : {}}
                      transition={{ duration: 0.5, delay: index * 0.2 + featureIndex * 0.1 }}
                      className="flex items-center space-x-3"
                    >
                      <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${service.gradient}`} />
                      <span className={`text-sm ${
                        theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
                      } ${language === 'ur' ? 'font-urdu' : ''}`}>
                        {feature}
                      </span>
                    </motion.div>
                  ))}
                </div>

                {/* Hover Effect */}
                <motion.div
                  className={`absolute bottom-4 right-4 w-8 h-8 rounded-full bg-gradient-to-r ${service.gradient} flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300`}
                >
                  <Icon className="w-4 h-4 text-white" />
                </motion.div>
              </motion.div>
            );
          })}
        </div>

        {/* Additional Services */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="grid md:grid-cols-3 gap-6"
        >
          {currentContent.additionalServices.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={index}
                whileHover={{ scale: 1.05, y: -5 }}
                className={`p-6 rounded-2xl ${
                  theme === 'dark' 
                    ? 'bg-white/5 border border-white/10' 
                    : 'bg-gray-50 border border-gray-200'
                } backdrop-blur-sm text-center group`}
              >
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  className="w-12 h-12 mx-auto mb-4 bg-gradient-to-r from-green-400 to-yellow-400 rounded-xl flex items-center justify-center"
                >
                  <Icon className="w-6 h-6 text-black" />
                </motion.div>
                
                <h4 className={`text-lg font-semibold mb-2 ${language === 'ur' ? 'font-urdu' : ''}`}>
                  {service.title}
                </h4>
                
                <p className={`text-sm ${
                  theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                } ${language === 'ur' ? 'font-urdu' : ''}`}>
                  {service.description}
                </p>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
};

export default Services;