import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

interface PartnersProps {
  theme: 'dark' | 'light';
  language: 'en' | 'ur';
}

const Partners: React.FC<PartnersProps> = ({ theme, language }) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const content = {
    en: {
      title: "Trusted Partners",
      subtitle: "Working with industry leaders to deliver excellence",
    },
    ur: {
      title: "بھروسے مند شراکت دار",
      subtitle: "بہترین خدمات فراہم کرنے کے لیے انڈسٹری کے رہنماؤں کے ساتھ کام",
    }
  };

  const currentContent = content[language];

  // Partner logos (using placeholder company names)
  const partners = [
    { name: "SolarTech Global", logo: "ST" },
    { name: "Green Energy Co", logo: "GE" },
    { name: "PowerMax Solutions", logo: "PM" },
    { name: "EcoVolt Systems", logo: "EV" },
    { name: "SunPower Industries", logo: "SP" },
    { name: "CleanTech Partners", logo: "CT" },
    { name: "Renewable Resources", logo: "RR" },
    { name: "Solar Dynamics", logo: "SD" },
  ];

  return (
    <section className={`py-20 ${theme === 'dark' ? 'bg-gray-900/30' : 'bg-gray-50/50'}`} ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className={`text-center mb-16 ${language === 'ur' ? 'rtl' : ''}`}
        >
          <h2 className={`text-4xl sm:text-5xl font-bold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
            <span className="bg-gradient-to-r from-green-400 to-yellow-400 bg-clip-text text-transparent">
              {currentContent.title}
            </span>
          </h2>
          <p className={`text-xl ${
            theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
          } max-w-3xl mx-auto ${language === 'ur' ? 'font-urdu' : ''}`}>
            {currentContent.subtitle}
          </p>
        </motion.div>

        {/* Partners Carousel */}
        <div className="relative overflow-hidden">
          <motion.div
            initial={{ opacity: 0 }}
            animate={inView ? { opacity: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex items-center"
          >
            {/* Scrolling Animation */}
            <motion.div
              animate={{
                x: [0, -100 * partners.length],
              }}
              transition={{
                duration: 20,
                repeat: Infinity,
                ease: "linear",
              }}
              className="flex items-center space-x-12 min-w-max"
            >
              {/* Duplicate partners for seamless loop */}
              {[...partners, ...partners].map((partner, index) => (
                <motion.div
                  key={index}
                  whileHover={{ scale: 1.1, y: -5 }}
                  className={`flex-shrink-0 w-24 h-24 ${
                    theme === 'dark' 
                      ? 'bg-white/10 border border-white/20' 
                      : 'bg-white border border-gray-200'
                  } rounded-2xl flex items-center justify-center backdrop-blur-sm shadow-lg group cursor-pointer`}
                >
                  <div className="text-center">
                    <div className={`text-2xl font-bold bg-gradient-to-r from-green-400 to-yellow-400 bg-clip-text text-transparent group-hover:from-yellow-400 group-hover:to-green-400 transition-all duration-300`}>
                      {partner.logo}
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>
        </div>

        {/* Stats Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8"
        >
          {[
            { value: "100+", label: language === 'en' ? "Global Partners" : "عالمی شراکت دار" },
            { value: "50K+", label: language === 'en' ? "Projects Completed" : "مکمل منصوبے" },
            { value: "25+", label: language === 'en' ? "Countries" : "ممالک" },
            { value: "99%", label: language === 'en' ? "Success Rate" : "کامیابی کی شرح" },
          ].map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.6 + index * 0.1 }}
              whileHover={{ scale: 1.05 }}
              className="text-center"
            >
              <div className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-green-400 to-yellow-400 bg-clip-text text-transparent mb-2">
                {stat.value}
              </div>
              <div className={`text-sm ${
                theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
              } ${language === 'ur' ? 'font-urdu' : ''}`}>
                {stat.label}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Partners;