import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { ChevronLeft, ChevronRight, Star, Award, Zap, Shield } from 'lucide-react';

interface ProductsProps {
  theme: 'dark' | 'light';
  language: 'en' | 'ur';
}

const Products: React.FC<ProductsProps> = ({ theme, language }) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const [activeCategory, setActiveCategory] = useState(0);

  const content = {
    en: {
      title: "Premium Products",
      subtitle: "World-Class Solar Technology for Maximum Efficiency",
      categories: [
        {
          name: "Solar Panels",
          products: [
            {
              name: "SolarMax Pro 550W",
              image: "https://images.pexels.com/photos/9875454/pexels-photo-9875454.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.9,
              price: "$299",
              features: ["22.5% Efficiency", "25 Year Warranty", "Weather Resistant", "Smart Monitoring"],
              specs: { power: "550W", efficiency: "22.5%", warranty: "25 years" }
            },
            {
              name: "EcoPanel Elite 450W",
              image: "https://images.pexels.com/photos/9875455/pexels-photo-9875455.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.8,
              price: "$229",
              features: ["21.8% Efficiency", "20 Year Warranty", "Lightweight", "Easy Installation"],
              specs: { power: "450W", efficiency: "21.8%", warranty: "20 years" }
            }
          ]
        },
        {
          name: "Inverters",
          products: [
            {
              name: "PowerMax 10kW",
              image: "https://images.pexels.com/photos/9875460/pexels-photo-9875460.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.9,
              price: "$1,299",
              features: ["97% Efficiency", "WiFi Monitoring", "Grid Tie", "Surge Protection"],
              specs: { power: "10kW", efficiency: "97%", monitoring: "WiFi" }
            },
            {
              name: "SmartInvert 5kW",
              image: "https://images.pexels.com/photos/9875461/pexels-photo-9875461.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.7,
              price: "$799",
              features: ["95% Efficiency", "Mobile App", "Compact Design", "Easy Setup"],
              specs: { power: "5kW", efficiency: "95%", monitoring: "Mobile App" }
            }
          ]
        },
        {
          name: "Batteries",
          products: [
            {
              name: "EnergyVault 20kWh",
              image: "https://images.pexels.com/photos/9875462/pexels-photo-9875462.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.8,
              price: "$8,999",
              features: ["LiFePO4 Technology", "10,000+ Cycles", "Smart BMS", "Modular Design"],
              specs: { capacity: "20kWh", cycles: "10,000+", technology: "LiFePO4" }
            },
            {
              name: "PowerBank 10kWh",
              image: "https://images.pexels.com/photos/9875463/pexels-photo-9875463.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.6,
              price: "$4,499",
              features: ["Lithium Ion", "8,000+ Cycles", "Compact Size", "Remote Monitoring"],
              specs: { capacity: "10kWh", cycles: "8,000+", technology: "Li-ion" }
            }
          ]
        },
        {
          name: "Smart Appliances",
          products: [
            {
              name: "Solar Water Heater 200L",
              image: "https://images.pexels.com/photos/9875464/pexels-photo-9875464.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.7,
              price: "$1,199",
              features: ["200L Capacity", "Vacuum Tubes", "Auto Temperature", "10 Year Warranty"],
              specs: { capacity: "200L", type: "Vacuum Tube", warranty: "10 years" }
            },
            {
              name: "Solar AC Unit 1.5 Ton",
              image: "https://images.pexels.com/photos/9875465/pexels-photo-9875465.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.5,
              price: "$2,299",
              features: ["1.5 Ton Capacity", "Inverter Technology", "Energy Saving", "Smart Controls"],
              specs: { capacity: "1.5 Ton", technology: "Inverter", efficiency: "5 Star" }
            }
          ]
        }
      ]
    },
    ur: {
      title: "پریمیم پروڈکٹس",
      subtitle: "زیادہ سے زیادہ کارکردگی کے لیے عالمی معیار کی سولر ٹیکنالوجی",
      categories: [
        {
          name: "سولر پینل",
          products: [
            {
              name: "سولرمیکس پرو 550W",
              image: "https://images.pexels.com/photos/9875454/pexels-photo-9875454.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.9,
              price: "$299",
              features: ["22.5% کارکردگی", "25 سال وارنٹی", "موسمی مزاحمت", "اسمارٹ مانیٹرنگ"],
              specs: { power: "550W", efficiency: "22.5%", warranty: "25 سال" }
            },
            {
              name: "ایکو پینل ایلیٹ 450W",
              image: "https://images.pexels.com/photos/9875455/pexels-photo-9875455.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.8,
              price: "$229",
              features: ["21.8% کارکردگی", "20 سال وارنٹی", "ہلکا وزن", "آسان تنصیب"],
              specs: { power: "450W", efficiency: "21.8%", warranty: "20 سال" }
            }
          ]
        },
        {
          name: "انورٹر",
          products: [
            {
              name: "پاورمیکس 10kW",
              image: "https://images.pexels.com/photos/9875460/pexels-photo-9875460.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.9,
              price: "$1,299",
              features: ["97% کارکردگی", "وائی فائی مانیٹرنگ", "گرڈ ٹائی", "سرج پروٹیکشن"],
              specs: { power: "10kW", efficiency: "97%", monitoring: "WiFi" }
            },
            {
              name: "اسمارٹ انورٹ 5kW",
              image: "https://images.pexels.com/photos/9875461/pexels-photo-9875461.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.7,
              price: "$799",
              features: ["95% کارکردگی", "موبائل ایپ", "کمپیکٹ ڈیزائن", "آسان سیٹ اپ"],
              specs: { power: "5kW", efficiency: "95%", monitoring: "موبائل ایپ" }
            }
          ]
        },
        {
          name: "بیٹریاں",
          products: [
            {
              name: "انرجی والٹ 20kWh",
              image: "https://images.pexels.com/photos/9875462/pexels-photo-9875462.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.8,
              price: "$8,999",
              features: ["LiFePO4 ٹیکنالوجی", "10,000+ سائیکل", "اسمارٹ BMS", "ماڈولر ڈیزائن"],
              specs: { capacity: "20kWh", cycles: "10,000+", technology: "LiFePO4" }
            },
            {
              name: "پاور بینک 10kWh",
              image: "https://images.pexels.com/photos/9875463/pexels-photo-9875463.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.6,
              price: "$4,499",
              features: ["لیتھیم آئن", "8,000+ سائیکل", "چھوٹا سائز", "ریموٹ مانیٹرنگ"],
              specs: { capacity: "10kWh", cycles: "8,000+", technology: "Li-ion" }
            }
          ]
        },
        {
          name: "اسمارٹ آلات",
          products: [
            {
              name: "سولر واٹر ہیٹر 200L",
              image: "https://images.pexels.com/photos/9875464/pexels-photo-9875464.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.7,
              price: "$1,199",
              features: ["200L گنجائش", "ویکیوم ٹیوب", "خودکار درجہ حرارت", "10 سال وارنٹی"],
              specs: { capacity: "200L", type: "Vacuum Tube", warranty: "10 سال" }
            },
            {
              name: "سولر AC یونٹ 1.5 ٹن",
              image: "https://images.pexels.com/photos/9875465/pexels-photo-9875465.jpeg?auto=compress&cs=tinysrgb&w=800",
              rating: 4.5,
              price: "$2,299",
              features: ["1.5 ٹن گنجائش", "انورٹر ٹیکنالوجی", "توانائی کی بچت", "اسمارٹ کنٹرولز"],
              specs: { capacity: "1.5 ٹن", technology: "انورٹر", efficiency: "5 سٹار" }
            }
          ]
        }
      ]
    }
  };

  const currentContent = content[language];

  return (
    <section id="products" className={`py-20 ${theme === 'dark' ? 'bg-black/50' : 'bg-white'}`} ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className={`text-center mb-16 ${language === 'ur' ? 'rtl' : ''}`}
        >
          <h2 className={`text-4xl sm:text-5xl font-bold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
            <span className="bg-gradient-to-r from-green-400 to-yellow-400 bg-clip-text text-transparent">
              {currentContent.title}
            </span>
          </h2>
          <p className={`text-xl ${
            theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
          } max-w-3xl mx-auto ${language === 'ur' ? 'font-urdu' : ''}`}>
            {currentContent.subtitle}
          </p>
        </motion.div>

        {/* Category Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex flex-wrap justify-center gap-4 mb-12"
        >
          {currentContent.categories.map((category, index) => (
            <motion.button
              key={index}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setActiveCategory(index)}
              className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                activeCategory === index
                  ? 'bg-gradient-to-r from-green-400 to-green-600 text-black shadow-lg'
                  : theme === 'dark'
                    ? 'bg-white/10 text-gray-300 hover:bg-white/20'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              } ${language === 'ur' ? 'font-urdu' : ''}`}
            >
              {category.name}
            </motion.button>
          ))}
        </motion.div>

        {/* Products Grid */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeCategory}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
            className="grid md:grid-cols-2 gap-8"
          >
            {currentContent.categories[activeCategory].products.map((product, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ 
                  scale: 1.02, 
                  y: -10,
                  boxShadow: theme === 'dark' 
                    ? '0 25px 50px rgba(0, 255, 136, 0.1)' 
                    : '0 25px 50px rgba(0, 0, 0, 0.1)'
                }}
                className={`rounded-3xl overflow-hidden ${
                  theme === 'dark' 
                    ? 'bg-white/5 border border-white/10' 
                    : 'bg-gray-50 border border-gray-200'
                } backdrop-blur-md group`}
              >
                {/* Product Image */}
                <div className="relative overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  
                  {/* Badges */}
                  <div className="absolute top-4 left-4 flex space-x-2">
                    <div className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-semibold flex items-center space-x-1">
                      <Award size={16} />
                      <span>Premium</span>
                    </div>
                  </div>

                  <div className="absolute top-4 right-4 bg-black/30 backdrop-blur-md text-white px-3 py-1 rounded-full text-sm font-semibold">
                    {product.price}
                  </div>
                </div>

                {/* Product Info */}
                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className={`text-xl font-bold ${language === 'ur' ? 'font-urdu' : ''}`}>
                      {product.name}
                    </h3>
                    <div className="flex items-center space-x-1">
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                      <span className="text-sm font-semibold">{product.rating}</span>
                    </div>
                  </div>

                  {/* Features */}
                  <div className="space-y-2 mb-6">
                    {product.features.map((feature, featureIndex) => (
                      <motion.div
                        key={featureIndex}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.3, delay: featureIndex * 0.1 }}
                        className="flex items-center space-x-3"
                      >
                        <Zap className="w-4 h-4 text-green-400" />
                        <span className={`text-sm ${
                          theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
                        } ${language === 'ur' ? 'font-urdu' : ''}`}>
                          {feature}
                        </span>
                      </motion.div>
                    ))}
                  </div>

                  {/* Specs */}
                  <div className={`grid grid-cols-2 gap-4 p-4 rounded-2xl ${
                    theme === 'dark' ? 'bg-white/5' : 'bg-white'
                  } border ${theme === 'dark' ? 'border-white/10' : 'border-gray-200'}`}>
                    {Object.entries(product.specs).map(([key, value], specIndex) => (
                      <div key={specIndex} className="text-center">
                        <div className={`text-lg font-bold bg-gradient-to-r from-green-400 to-yellow-400 bg-clip-text text-transparent`}>
                          {value}
                        </div>
                        <div className={`text-xs ${
                          theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                        } uppercase tracking-wide ${language === 'ur' ? 'font-urdu' : ''}`}>
                          {key}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Action Button */}
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full mt-6 bg-gradient-to-r from-green-400 to-green-600 text-black font-semibold py-3 rounded-xl flex items-center justify-center space-x-2 shadow-lg"
                  >
                    <span className={language === 'ur' ? 'font-urdu' : ''}>
                      {language === 'en' ? 'Get Quote' : 'قیمت حاصل کریں'}
                    </span>
                    <ChevronRight size={20} />
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  );
};

export default Products;