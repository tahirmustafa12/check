import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Award, Users, Target, Lightbulb, Heart, Globe } from 'lucide-react';

interface AboutProps {
  theme: 'dark' | 'light';
  language: 'en' | 'ur';
}

const About: React.FC<AboutProps> = ({ theme, language }) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const content = {
    en: {
      title: "About SolarTech",
      subtitle: "Leading the renewable energy revolution since 1998",
      description: "We are committed to providing sustainable energy solutions that power communities, reduce environmental impact, and create a brighter future for generations to come. Our expertise spans residential, commercial, and industrial solar installations with cutting-edge technology and unmatched service quality.",
      mission: "To accelerate the world's transition to sustainable energy through innovative solar solutions and exceptional customer service.",
      vision: "A world powered entirely by clean, renewable energy where every community has access to affordable, sustainable power.",
      values: [
        {
          icon: Heart,
          title: "Customer First",
          description: "Your satisfaction is our top priority in everything we do"
        },
        {
          icon: Lightbulb,
          title: "Innovation",
          description: "Constantly pushing boundaries with latest technology"
        },
        {
          icon: Globe,
          title: "Sustainability",
          description: "Committed to protecting our planet for future generations"
        },
        {
          icon: Award,
          title: "Excellence",
          description: "Delivering superior quality in every project we undertake"
        }
      ],
      achievements: [
        { icon: Award, title: "Industry Leader", desc: "Recognized as top solar company for 5 consecutive years" },
        { icon: Users, title: "Expert Team", desc: "Over 200 certified engineers and technicians" },
        { icon: Target, title: "Mission Driven", desc: "Committed to carbon neutral future by 2030" }
      ]
    },
    ur: {
      title: "سولرٹیک کے بارے میں",
      subtitle: "1998 سے قابل تجدید توانائی کے انقلاب کی قیادت",
      description: "ہم پائیدار توانائی کے حل فراہم کرنے کے لیے پرعزم ہیں جو کمیونٹیز کو طاقت فراہم کرتے ہیں، ماحولیاتی اثرات کو کم کرتے ہیں، اور آنے والی نسلوں کے لیے ایک روشن مستقبل بناتے ہیں۔",
      mission: "جدید سولر حلول اور بہترین کسٹمر سروس کے ذریعے دنیا کی پائیدار توانائی میں منتقلی کو تیز کرنا۔",
      vision: "ایک ایسی دنیا جو مکمل طور پر صاف، قابل تجدید توانائی سے چلایا جائے جہاں ہر کمیونٹی کو سستی، پائیدار بجلی تک رسائی ہو۔",
      values: [
        {
          icon: Heart,
          title: "کسٹمر فرسٹ",
          description: "ہم جو کچھ بھی کرتے ہیں اس میں آپ کا اطمینان ہماری اولین ترجیح ہے"
        },
        {
          icon: Lightbulb,
          title: "اختراع",
          description: "جدید ترین ٹیکنالوجی کے ساتھ مسلسل حدود کو آگے بڑھانا"
        },
        {
          icon: Globe,
          title: "پائیداری",
          description: "آنے والی نسلوں کے لیے اپنے سیارے کی حفاظت کے لیے پرعزم"
        },
        {
          icon: Award,
          title: "بہتری",
          description: "ہمارے ہر منصوبے میں اعلیٰ کوالٹی کی فراہمی"
        }
      ],
      achievements: [
        { icon: Award, title: "انڈسٹری لیڈر", desc: "مسلسل 5 سالوں تک ٹاپ سولر کمپنی کے طور پر تسلیم شدہ" },
        { icon: Users, title: "ماہر ٹیم", desc: "200 سے زیادہ تصدیق شدہ انجینیئر اور ٹیکنیشن" },
        { icon: Target, title: "مشن محور", desc: "2030 تک کاربن نیوٹرل مستقبل کے لیے پرعزم" }
      ]
    }
  };

  const currentContent = content[language];

  return (
    <section id="about" className={`py-20 ${theme === 'dark' ? 'bg-black/30' : 'bg-white'}`} ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className={`text-center mb-16 ${language === 'ur' ? 'rtl' : ''}`}
        >
          <h2 className={`text-4xl sm:text-5xl font-bold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
            <span className="bg-gradient-to-r from-green-400 to-yellow-400 bg-clip-text text-transparent">
              {currentContent.title}
            </span>
          </h2>
          <p className={`text-xl ${
            theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
          } max-w-3xl mx-auto mb-8 ${language === 'ur' ? 'font-urdu' : ''}`}>
            {currentContent.subtitle}
          </p>
          <p className={`text-lg ${
            theme === 'dark' ? 'text-gray-400' : 'text-gray-700'
          } max-w-4xl mx-auto leading-relaxed ${language === 'ur' ? 'font-urdu' : ''}`}>
            {currentContent.description}
          </p>
        </motion.div>

        {/* Mission & Vision */}
        <div className="grid lg:grid-cols-2 gap-12 mb-20">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className={`p-8 rounded-3xl ${
              theme === 'dark' 
                ? 'bg-green-500/10 border border-green-500/20' 
                : 'bg-green-50 border border-green-200'
            } backdrop-blur-sm`}
          >
            <h3 className={`text-2xl font-bold mb-4 text-green-400 ${language === 'ur' ? 'font-urdu' : ''}`}>
              {language === 'en' ? 'Our Mission' : 'ہمارا مشن'}
            </h3>
            <p className={`${
              theme === 'dark' ? 'text-gray-300' : 'text-gray-700'
            } leading-relaxed ${language === 'ur' ? 'font-urdu' : ''}`}>
              {currentContent.mission}
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className={`p-8 rounded-3xl ${
              theme === 'dark' 
                ? 'bg-yellow-500/10 border border-yellow-500/20' 
                : 'bg-yellow-50 border border-yellow-200'
            } backdrop-blur-sm`}
          >
            <h3 className={`text-2xl font-bold mb-4 text-yellow-400 ${language === 'ur' ? 'font-urdu' : ''}`}>
              {language === 'en' ? 'Our Vision' : 'ہمارا وژن'}
            </h3>
            <p className={`${
              theme === 'dark' ? 'text-gray-300' : 'text-gray-700'
            } leading-relaxed ${language === 'ur' ? 'font-urdu' : ''}`}>
              {currentContent.vision}
            </p>
          </motion.div>
        </div>

        {/* Values */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mb-20"
        >
          <h3 className={`text-3xl font-bold text-center mb-12 ${language === 'ur' ? 'font-urdu' : ''}`}>
            {language === 'en' ? 'Our Values' : 'ہماری اقدار'}
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {currentContent.values.map((value, index) => {
              const Icon = value.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={inView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.8 + index * 0.1 }}
                  whileHover={{ scale: 1.05, y: -5 }}
                  className={`text-center p-6 rounded-2xl ${
                    theme === 'dark' 
                      ? 'bg-white/5 border border-white/10' 
                      : 'bg-gray-50 border border-gray-200'
                  } backdrop-blur-sm group`}
                >
                  <motion.div
                    whileHover={{ rotate: 10, scale: 1.1 }}
                    className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-green-400 to-yellow-400 rounded-2xl flex items-center justify-center"
                  >
                    <Icon className="w-8 h-8 text-black" />
                  </motion.div>
                  <h4 className={`text-xl font-semibold mb-3 ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {value.title}
                  </h4>
                  <p className={`text-sm ${
                    theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                  } ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {value.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Achievements */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 1 }}
          className="grid md:grid-cols-3 gap-8"
        >
          {currentContent.achievements.map((achievement, index) => {
            const Icon = achievement.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={inView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.5, delay: 1.2 + index * 0.1 }}
                whileHover={{ scale: 1.02, y: -5 }}
                className={`p-6 rounded-2xl ${
                  theme === 'dark' 
                    ? 'bg-gradient-to-br from-gray-800/50 to-gray-900/50 border border-white/10' 
                    : 'bg-gradient-to-br from-gray-50 to-white border border-gray-200'
                } backdrop-blur-sm shadow-lg text-center group`}
              >
                <motion.div
                  whileHover={{ rotate: -10, scale: 1.1 }}
                  className="w-12 h-12 mx-auto mb-4 bg-gradient-to-r from-green-400 to-yellow-400 rounded-xl flex items-center justify-center"
                >
                  <Icon className="w-6 h-6 text-black" />
                </motion.div>
                <h4 className={`text-lg font-semibold mb-2 ${language === 'ur' ? 'font-urdu' : ''}`}>
                  {achievement.title}
                </h4>
                <p className={`text-sm ${
                  theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                } ${language === 'ur' ? 'font-urdu' : ''}`}>
                  {achievement.desc}
                </p>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
};

export default About;