import React from 'react';
import { motion } from 'framer-motion';
import { Sun, Facebook, Twitter, Instagram, Linkedin, Mail, Phone, MapPin } from 'lucide-react';

interface FooterProps {
  theme: 'dark' | 'light';
  language: 'en' | 'ur';
}

const Footer: React.FC<FooterProps> = ({ theme, language }) => {
  const content = {
    en: {
      company: "SolarTech",
      tagline: "Powering the Future with Clean Energy",
      description: "Leading provider of sustainable solar solutions for residential, commercial, and industrial applications worldwide.",
      quickLinks: {
        title: "Quick Links",
        links: [
          { name: "About Us", href: "#about" },
          { name: "Services", href: "#services" },
          { name: "Products", href: "#products" },
          { name: "Contact", href: "#contact" }
        ]
      },
      services: {
        title: "Services",
        links: [
          { name: "Residential Solar", href: "#" },
          { name: "Commercial Solar", href: "#" },
          { name: "Industrial Solutions", href: "#" },
          { name: "Maintenance & Support", href: "#" }
        ]
      },
      contact: {
        title: "Contact Info",
        phone: "+1 (555) 123-4567",
        email: "info@solartech.com",
        address: "123 Solar Street, Green City, GC 12345"
      },
      newsletter: {
        title: "Stay Updated",
        description: "Subscribe to get the latest news and offers",
        placeholder: "Enter your email",
        button: "Subscribe"
      },
      copyright: "© 2025 SolarTech. All rights reserved.",
      privacy: "Privacy Policy",
      terms: "Terms of Service"
    },
    ur: {
      company: "سولرٹیک",
      tagline: "صاف توانائی کے ساتھ مستقبل کو طاقت بخشنا",
      description: "دنیا بھر میں رہائشی، تجارتی اور صنعتی استعمال کے لیے پائیدار سولر حل کا معروف فراہم کنندہ۔",
      quickLinks: {
        title: "فوری لنکس",
        links: [
          { name: "ہمارے بارے میں", href: "#about" },
          { name: "خدمات", href: "#services" },
          { name: "پروڈکٹس", href: "#products" },
          { name: "رابطہ", href: "#contact" }
        ]
      },
      services: {
        title: "خدمات",
        links: [
          { name: "رہائشی سولر", href: "#" },
          { name: "تجارتی سولر", href: "#" },
          { name: "صنعتی حل", href: "#" },
          { name: "دیکھ بھال اور سپورٹ", href: "#" }
        ]
      },
      contact: {
        title: "رابطے کی معلومات",
        phone: "+1 (555) 123-4567",
        email: "info@solartech.com",
        address: "123 سولر سٹریٹ، گرین سٹی، GC 12345"
      },
      newsletter: {
        title: "اپڈیٹ رہیں",
        description: "تازہ خبریں اور پیشکشیں حاصل کرنے کے لیے سبسکرائب کریں",
        placeholder: "اپنا ای میل داخل کریں",
        button: "سبسکرائب"
      },
      copyright: "© 2025 سولرٹیک۔ تمام حقوق محفوظ ہیں۔",
      privacy: "پرائیویسی پالیسی",
      terms: "سروس کی شرائط"
    }
  };

  const currentContent = content[language];

  return (
    <footer className={`${
      theme === 'dark' 
        ? 'bg-gradient-to-b from-gray-900 to-black' 
        : 'bg-gradient-to-b from-gray-100 to-gray-200'
    } pt-16 pb-8`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Content */}
        <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-8 mb-12">
          {/* Company Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="lg:col-span-1"
          >
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-r from-green-400 to-yellow-400 rounded-full flex items-center justify-center">
                <Sun className="w-6 h-6 text-black" />
              </div>
              <span className={`text-2xl font-bold bg-gradient-to-r from-green-400 to-yellow-400 bg-clip-text text-transparent`}>
                {currentContent.company}
              </span>
            </div>
            <p className={`${
              theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
            } mb-4 leading-relaxed ${language === 'ur' ? 'font-urdu' : ''}`}>
              {currentContent.description}
            </p>
            
            {/* Social Media Icons */}
            <div className="flex space-x-4">
              {[Facebook, Twitter, Instagram, Linkedin].map((Icon, index) => (
                <motion.a
                  key={index}
                  href="#"
                  whileHover={{ scale: 1.2, y: -2 }}
                  whileTap={{ scale: 0.9 }}
                  className={`w-10 h-10 rounded-full ${
                    theme === 'dark' 
                      ? 'bg-white/10 hover:bg-green-500/20' 
                      : 'bg-gray-200 hover:bg-green-100'
                  } flex items-center justify-center transition-colors`}
                >
                  <Icon size={20} className="text-green-400" />
                </motion.a>
              ))}
            </div>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <h4 className={`text-lg font-semibold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
              {currentContent.quickLinks.title}
            </h4>
            <ul className="space-y-3">
              {currentContent.quickLinks.links.map((link, index) => (
                <li key={index}>
                  <motion.a
                    href={link.href}
                    whileHover={{ x: 5 }}
                    className={`${
                      theme === 'dark' ? 'text-gray-400 hover:text-green-400' : 'text-gray-600 hover:text-green-600'
                    } transition-colors ${language === 'ur' ? 'font-urdu' : ''}`}
                  >
                    {link.name}
                  </motion.a>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Services */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <h4 className={`text-lg font-semibold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
              {currentContent.services.title}
            </h4>
            <ul className="space-y-3">
              {currentContent.services.links.map((link, index) => (
                <li key={index}>
                  <motion.a
                    href={link.href}
                    whileHover={{ x: 5 }}
                    className={`${
                      theme === 'dark' ? 'text-gray-400 hover:text-green-400' : 'text-gray-600 hover:text-green-600'
                    } transition-colors ${language === 'ur' ? 'font-urdu' : ''}`}
                  >
                    {link.name}
                  </motion.a>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Contact & Newsletter */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="space-y-6"
          >
            {/* Contact Info */}
            <div>
              <h4 className={`text-lg font-semibold mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
                {currentContent.contact.title}
              </h4>
              <div className="space-y-3">
                {[
                  { icon: Phone, text: currentContent.contact.phone },
                  { icon: Mail, text: currentContent.contact.email },
                  { icon: MapPin, text: currentContent.contact.address }
                ].map((item, index) => {
                  const Icon = item.icon;
                  return (
                    <div key={index} className="flex items-center space-x-3">
                      <Icon size={16} className="text-green-400 flex-shrink-0" />
                      <span className={`text-sm ${
                        theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                      } ${language === 'ur' ? 'font-urdu' : ''}`}>
                        {item.text}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Newsletter */}
            <div>
              <h4 className={`text-lg font-semibold mb-2 ${language === 'ur' ? 'font-urdu' : ''}`}>
                {currentContent.newsletter.title}
              </h4>
              <p className={`text-sm ${
                theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
              } mb-4 ${language === 'ur' ? 'font-urdu' : ''}`}>
                {currentContent.newsletter.description}
              </p>
              <div className="flex space-x-2">
                <input
                  type="email"
                  placeholder={currentContent.newsletter.placeholder}
                  className={`flex-1 px-3 py-2 rounded-lg text-sm ${
                    theme === 'dark' 
                      ? 'bg-white/10 border border-white/20 text-white placeholder-gray-400' 
                      : 'bg-white border border-gray-300 text-black placeholder-gray-500'
                  } focus:outline-none focus:ring-2 focus:ring-green-400`}
                />
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`px-4 py-2 bg-gradient-to-r from-green-400 to-green-600 text-black text-sm font-semibold rounded-lg ${language === 'ur' ? 'font-urdu' : ''}`}
                >
                  {currentContent.newsletter.button}
                </motion.button>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Bottom Footer */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className={`pt-8 border-t ${
            theme === 'dark' ? 'border-gray-800' : 'border-gray-300'
          } flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0`}
        >
          <p className={`text-sm ${
            theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
          } ${language === 'ur' ? 'font-urdu' : ''}`}>
            {currentContent.copyright}
          </p>
          
          <div className="flex space-x-6">
            <motion.a
              href="#"
              whileHover={{ scale: 1.05 }}
              className={`text-sm ${
                theme === 'dark' ? 'text-gray-400 hover:text-green-400' : 'text-gray-600 hover:text-green-600'
              } transition-colors ${language === 'ur' ? 'font-urdu' : ''}`}
            >
              {currentContent.privacy}
            </motion.a>
            <motion.a
              href="#"
              whileHover={{ scale: 1.05 }}
              className={`text-sm ${
                theme === 'dark' ? 'text-gray-400 hover:text-green-400' : 'text-gray-600 hover:text-green-600'
              } transition-colors ${language === 'ur' ? 'font-urdu' : ''}`}
            >
              {currentContent.terms}
            </motion.a>
          </div>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;