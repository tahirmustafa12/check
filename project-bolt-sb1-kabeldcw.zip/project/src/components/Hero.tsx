import React from 'react';
import { motion } from 'framer-motion';
import { ChevronRight, Play, Zap, Leaf, Shield } from 'lucide-react';

interface HeroProps {
  theme: 'dark' | 'light';
  language: 'en' | 'ur';
}

const Hero: React.FC<HeroProps> = ({ theme, language }) => {
  const content = {
    en: {
      headline: "Power Your Future with Clean Energy",
      subheadline: "Leading solar solutions for residential, commercial, and industrial applications. Join the green revolution today.",
      cta: "Get Free Quote",
      watch: "Watch Demo",
      stats: [
        { value: "50K+", label: "Installations" },
        { value: "25+", label: "Years Experience" },
        { value: "99%", label: "Customer Satisfaction" }
      ],
      features: [
        { icon: Zap, title: "High Efficiency", desc: "Premium solar panels with 22%+ efficiency" },
        { icon: Leaf, title: "Eco Friendly", desc: "Reduce carbon footprint by 80%" },
        { icon: Shield, title: "25 Year Warranty", desc: "Long-term protection guaranteed" }
      ]
    },
    ur: {
      headline: "صاف توانائی کے ساتھ اپنا مستقبل روشن کریں",
      subheadline: "رہائشی، تجارتی اور صنعتی استعمال کے لیے بہترین سولر حل۔ آج ہی سبز انقلاب میں شامل ہوں۔",
      cta: "مفت قیمت حاصل کریں",
      watch: "ڈیمو دیکھیں",
      stats: [
        { value: "50K+", label: "تنصیبات" },
        { value: "25+", label: "سال تجربہ" },
        { value: "99%", label: "کسٹمر اطمینان" }
      ],
      features: [
        { icon: Zap, title: "اعلیٰ کارکردگی", desc: "22%+ کارکردگی کے ساتھ پریمیم سولر پینل" },
        { icon: Leaf, title: "ماحول دوست", desc: "کاربن فوٹ پرنٹ میں 80% کمی" },
        { icon: Shield, title: "25 سال وارنٹی", desc: "طویل مدتی تحفظ کی ضمانت" }
      ]
    }
  };

  const currentContent = content[language];

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Video Background */}
      <div className="absolute inset-0 z-0">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-cover"
        >
          <source src="https://videos.pexels.com/video-files/8979444/8979444-hd_1920_1080_25fps.mp4" type="video/mp4" />
        </video>
        <div className={`absolute inset-0 ${
          theme === 'dark' 
            ? 'bg-black/70 bg-gradient-to-r from-black/80 via-black/60 to-black/80' 
            : 'bg-white/30 bg-gradient-to-r from-white/50 via-white/30 to-white/50'
        }`}></div>
      </div>

      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ 
              opacity: [0, 1, 0],
              scale: [0, 1, 0],
              x: [0, Math.random() * 400 - 200],
              y: [0, Math.random() * 400 - 200]
            }}
            transition={{
              duration: Math.random() * 10 + 10,
              repeat: Infinity,
              delay: Math.random() * 5
            }}
            className="absolute w-2 h-2 bg-green-400 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className={`text-center lg:text-left ${language === 'ur' ? 'lg:text-right' : ''}`}
          >
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.8 }}
              className={`text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 leading-tight ${
                language === 'ur' ? 'font-urdu' : ''
              }`}
            >
              <span className="bg-gradient-to-r from-green-400 via-yellow-400 to-orange-400 bg-clip-text text-transparent">
                {currentContent.headline}
              </span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.8 }}
              className={`text-lg sm:text-xl mb-8 ${
                theme === 'dark' ? 'text-gray-300' : 'text-gray-700'
              } max-w-2xl ${language === 'ur' ? 'font-urdu' : ''}`}
            >
              {currentContent.subheadline}
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.8 }}
              className="flex flex-col sm:flex-row gap-4 mb-12 justify-center lg:justify-start"
            >
              <motion.button
                whileHover={{ 
                  scale: 1.05, 
                  boxShadow: '0 20px 40px rgba(34, 197, 94, 0.3)' 
                }}
                whileTap={{ scale: 0.95 }}
                className="bg-gradient-to-r from-green-400 to-green-600 text-black px-8 py-4 rounded-full font-semibold text-lg flex items-center justify-center space-x-2 shadow-2xl"
              >
                <span className={language === 'ur' ? 'font-urdu' : ''}>{currentContent.cta}</span>
                <ChevronRight size={20} />
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`border-2 ${
                  theme === 'dark' ? 'border-white/30 text-white' : 'border-black/30 text-black'
                } px-8 py-4 rounded-full font-semibold text-lg flex items-center justify-center space-x-2 backdrop-blur-sm transition-colors hover:bg-white/10`}
              >
                <Play size={20} />
                <span className={language === 'ur' ? 'font-urdu' : ''}>{currentContent.watch}</span>
              </motion.button>
            </motion.div>

            {/* Stats */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.8 }}
              className="grid grid-cols-3 gap-8 mb-8"
            >
              {currentContent.stats.map((stat, index) => (
                <motion.div
                  key={index}
                  whileHover={{ scale: 1.05 }}
                  className="text-center"
                >
                  <div className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-green-400 to-yellow-400 bg-clip-text text-transparent">
                    {stat.value}
                  </div>
                  <div className={`text-sm ${
                    theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                  } ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {stat.label}
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>

          {/* Feature Cards */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="space-y-6"
          >
            {currentContent.features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6 + index * 0.2, duration: 0.8 }}
                  whileHover={{ scale: 1.02, y: -5 }}
                  className={`p-6 rounded-2xl ${
                    theme === 'dark' 
                      ? 'bg-white/5 border border-white/10' 
                      : 'bg-black/5 border border-black/10'
                  } backdrop-blur-md shadow-xl`}
                >
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-green-400 to-yellow-400 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Icon className="w-6 h-6 text-black" />
                    </div>
                    <div className="flex-1">
                      <h3 className={`text-xl font-semibold mb-2 ${language === 'ur' ? 'font-urdu' : ''}`}>
                        {feature.title}
                      </h3>
                      <p className={`${
                        theme === 'dark' ? 'text-gray-300' : 'text-gray-700'
                      } ${language === 'ur' ? 'font-urdu' : ''}`}>
                        {feature.desc}
                      </p>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 0.8 }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className={`w-6 h-10 border-2 ${
            theme === 'dark' ? 'border-white/30' : 'border-black/30'
          } rounded-full flex justify-center`}
        >
          <motion.div
            animate={{ y: [0, 16, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className={`w-1 h-3 ${
              theme === 'dark' ? 'bg-white' : 'bg-black'
            } rounded-full mt-2`}
          />
        </motion.div>
      </motion.div>
    </section>
  );
};

export default Hero;