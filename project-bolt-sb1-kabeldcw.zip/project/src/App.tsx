import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Sun, 
  Lightbulb, 
  Shield, 
  Home, 
  Menu, 
  X, 
  ChevronRight,
  Phone,
  Mail,
  MapPin,
  Facebook,
  Twitter,
  Instagram,
  Linkedin,
  Moon,
  Globe
} from 'lucide-react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import Products from './components/Products';
import Partners from './components/Partners';
import About from './components/About';
import Contact from './components/Contact';
import Footer from './components/Footer';
import SolarSolutions from './components/miniSites/SolarSolutions';
import SmartLighting from './components/miniSites/SmartLighting';
import SecuritySystems from './components/miniSites/SecuritySystems';
import Appliances from './components/miniSites/Appliances';

type MiniSite = 'main' | 'solar' | 'lighting' | 'security' | 'appliances';
type Theme = 'dark' | 'light';
type Language = 'en' | 'ur';

function App() {
  const [currentSite, setCurrentSite] = useState<MiniSite>('main');
  const [theme, setTheme] = useState<Theme>('dark');
  const [language, setLanguage] = useState<Language>('en');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'ur' : 'en');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="text-center"
        >
          <div className="w-16 h-16 border-4 border-green-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <h2 className="text-2xl font-bold text-white">SolarTech</h2>
          <p className="text-green-400">Powering the Future</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen transition-colors duration-500 ${
      theme === 'dark' ? 'bg-black text-white' : 'bg-white text-black'
    }`}>
      <Navbar 
        currentSite={currentSite}
        setCurrentSite={setCurrentSite}
        theme={theme}
        toggleTheme={toggleTheme}
        language={language}
        toggleLanguage={toggleLanguage}
      />
      
      <AnimatePresence mode="wait">
        <motion.main
          key={currentSite}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.5 }}
        >
          {currentSite === 'main' && (
            <>
              <Hero theme={theme} language={language} />
              <Services theme={theme} language={language} />
              <Products theme={theme} language={language} />
              <Partners theme={theme} language={language} />
              <About theme={theme} language={language} />
              <Contact theme={theme} language={language} />
            </>
          )}
          {currentSite === 'solar' && <SolarSolutions theme={theme} language={language} />}
          {currentSite === 'lighting' && <SmartLighting theme={theme} language={language} />}
          {currentSite === 'security' && <SecuritySystems theme={theme} language={language} />}
          {currentSite === 'appliances' && <Appliances theme={theme} language={language} />}
        </motion.main>
      </AnimatePresence>
      
      <Footer theme={theme} language={language} />
    </div>
  );
}

export default App;